export const processContent = (html: string): string => {
  // Create a temporary DOM element to parse HTML
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');

  // Find all iframes
  const iframes = doc.querySelectorAll('iframe');
  
  iframes.forEach(iframe => {
    const src = iframe.getAttribute('src');
    if (!src) return;

    // Check for Bilibili video URLs (regular video page)
    // pattern: https://www.bilibili.com/video/BV...
    const bilibiliRegex = /bilibili\.com\/video\/(BV[a-zA-Z0-9]+)/;
    const match = src.match(bilibiliRegex);

    if (match && match[1]) {
      // Replace with player embed using the specific format requested
      const bvid = match[1];
      iframe.src = `//player.bilibili.com/player.html?isOutside=true&bvid=${bvid}&p=1&autoplay=0`;
      iframe.setAttribute('scrolling', 'no');
      iframe.setAttribute('border', '0');
      iframe.setAttribute('frameborder', 'no');
      iframe.setAttribute('framespacing', '0');
      iframe.setAttribute('allowfullscreen', 'true');
      
      // Remove inline styles that might interfere with CSS classes
      iframe.style.width = '';
      iframe.style.height = '';
      
      // Add a class for styling
      iframe.classList.add('bilibili-player');
      
      // Wrap in a responsive container if not already wrapped
      const wrapper = doc.createElement('div');
      wrapper.className = 'bilibili-player-wrapper';
      iframe.parentNode?.insertBefore(wrapper, iframe);
      wrapper.appendChild(iframe);
    }
  });

  return doc.body.innerHTML;
};
