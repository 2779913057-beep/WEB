// API 服务层 - 用于与后端通信

// @ts-ignore
const API_BASE = typeof window !== 'undefined' && window.location.port === '5173' 
  ? 'http://localhost:3001/api' 
  : '/api';

// 通用请求函数
async function request<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: '请求失败' }));
    throw new Error(error.error || '请求失败');
  }

  return response.json();
}

// ========== 认证 API ==========
export const authApi = {
  login: (username: string, password: string) =>
    request<{ user: any; pointsAwarded?: number }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),

  register: (data: {
    username: string;
    password: string;
    nickname?: string;
    gender?: string;
    phone?: string;
    email?: string;
    securityQuestion?: string;
    securityAnswer?: string;
  }) =>
    request<{ user: any }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};

// ========== 用户 API ==========
export const usersApi = {
  getAll: () => request<any[]>('/users'),

  getById: (id: string) => request<any>(`/users/${id}`),

  update: (id: string, data: any) =>
    request<any>(`/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    request<{ success: boolean }>(`/users/${id}`, {
      method: 'DELETE',
    }),
};

// ========== 分类 API ==========
export const categoriesApi = {
  getAll: () => request<any[]>('/categories'),

  create: (data: { name: string; description: string }) =>
    request<any>('/categories', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    request<{ success: boolean }>(`/categories/${id}`, {
      method: 'DELETE',
    }),
};

// ========== 帖子 API ==========
export const threadsApi = {
  getAll: () => request<any[]>('/threads'),

  getById: (id: string) => request<any>(`/threads/${id}`),

  create: (data: any) =>
    request<any>('/threads', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  update: (id: string, data: any) =>
    request<any>(`/threads/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  delete: (id: string) =>
    request<{ success: boolean }>(`/threads/${id}`, {
      method: 'DELETE',
    }),
};

// ========== 回复 API ==========
export const postsApi = {
  getAll: (threadId?: string) =>
    request<any[]>(threadId ? `/posts?threadId=${threadId}` : '/posts'),

  create: (data: any) =>
    request<any>('/posts', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};

// ========== 通知 API ==========
export const notificationsApi = {
  getByUser: (userId: string) => request<any[]>(`/notifications/${userId}`),

  markAsRead: (id: string) =>
    request<{ success: boolean }>(`/notifications/${id}/read`, {
      method: 'PUT',
    }),
};

// ========== 私信 API ==========
export const messagesApi = {
  getByUser: (userId: string) => request<any[]>(`/messages/${userId}`),

  send: (data: { senderId: string; receiverId: string; content: string }) =>
    request<any>('/messages', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};

// ========== 兑换码 API ==========
export const codesApi = {
  getAll: () => request<any[]>('/codes'),

  generate: (points: number) =>
    request<any>('/codes', {
      method: 'POST',
      body: JSON.stringify({ points }),
    }),

  redeem: (code: string, userId: string) =>
    request<{ points: number }>('/codes/redeem', {
      method: 'POST',
      body: JSON.stringify({ code, userId }),
    }),
};

// ========== 统计 API ==========
export const statsApi = {
  get: () => request<{ totalVisits: number; dailyVisits: number }>('/stats'),

  recordVisit: () =>
    request<{ totalVisits: number; dailyVisits: number }>('/stats/visit', {
      method: 'POST',
    }),
};

// ========== 审核 API ==========
export const moderationApi = {
  getRules: () => request<any>('/moderation'),

  updateRules: (data: any) =>
    request<any>('/moderation', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
};
