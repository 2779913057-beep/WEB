import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trash2, Download, Upload, AlertTriangle, Database, RefreshCw } from 'lucide-react';

export const DataManagement: React.FC = () => {
  const navigate = useNavigate();
  const [showConfirm, setShowConfirm] = useState(false);
  const [importData, setImportData] = useState('');

  // 获取所有localStorage数据的统计
  const getStorageStats = () => {
    const keys = [
      'forum_users',
      'forum_threads',
      'forum_posts',
      'forum_categories',
      'forum_notifications',
      'forum_messages',
      'forum_session',
      'forum_redemption_codes',
      'forum_banned_keywords',
      'forum_moderation_rules',
      'forum_follow_activities',
      'forum_site_visits',
      'forum_daily_visits',
      'forum_last_visit_date'
    ];

    const stats = keys.map(key => {
      const data = localStorage.getItem(key);
      return {
        key,
        size: data ? (data.length / 1024).toFixed(2) : '0',
        exists: !!data
      };
    });

    return stats;
  };

  const stats = getStorageStats();
  const totalSize = stats.reduce((sum, stat) => sum + parseFloat(stat.size), 0).toFixed(2);

  // 清空所有数据
  const handleClearAll = () => {
    if (!showConfirm) {
      setShowConfirm(true);
      return;
    }

    // 清空所有论坛相关数据
    stats.forEach(stat => {
      localStorage.removeItem(stat.key);
    });

    alert('所有数据已清空！页面即将刷新。');
    window.location.href = '/';
  };

  // 导出数据
  const handleExport = () => {
    const data: any = {};
    stats.forEach(stat => {
      const value = localStorage.getItem(stat.key);
      if (value) {
        data[stat.key] = value;
      }
    });

    const dataStr = JSON.stringify(data, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `forum-data-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    alert('数据已导出！');
  };

  // 导入数据
  const handleImport = () => {
    if (!importData.trim()) {
      alert('请先粘贴导入的数据！');
      return;
    }

    try {
      const data = JSON.parse(importData);
      
      Object.keys(data).forEach(key => {
        localStorage.setItem(key, data[key]);
      });

      alert('数据导入成功！页面即将刷新。');
      window.location.href = '/';
    } catch (error) {
      alert('导入失败：数据格式错误！');
    }
  };

  // 清除缓存但保留用户数据
  const handleClearCache = () => {
    localStorage.removeItem('forum_session');
    sessionStorage.clear();
    
    alert('缓存已清理！页面即将刷新。');
    window.location.reload();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 bg-blue-100 rounded-full">
            <Database className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">数据管理</h1>
            <p className="text-sm text-slate-500">管理浏览器本地存储的数据</p>
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-yellow-800">
              <p className="font-semibold mb-1">重要提示</p>
              <p>此论坛的所有数据都存储在浏览器的 localStorage 中，而不是服务器数据库。</p>
              <p className="mt-1">这意味着：</p>
              <ul className="list-disc ml-5 mt-1 space-y-1">
                <li>每个浏览器有独立的数据，不同浏览器之间不共享</li>
                <li>清除浏览器数据会导致所有内容丢失</li>
                <li>建议定期导出数据进行备份</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Storage Stats */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-lg font-bold text-slate-900 mb-4">存储统计</h2>
        <div className="space-y-2">
          <div className="flex justify-between items-center pb-2 border-b border-slate-200">
            <span className="font-medium text-slate-700">总大小</span>
            <span className="text-lg font-bold text-indigo-600">{totalSize} KB</span>
          </div>
          {stats.map(stat => stat.exists && (
            <div key={stat.key} className="flex justify-between items-center text-sm">
              <span className="text-slate-600">{stat.key}</span>
              <span className="text-slate-400">{stat.size} KB</span>
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Export */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-3">
            <Download className="h-5 w-5 text-green-600" />
            <h3 className="font-bold text-slate-900">导出数据</h3>
          </div>
          <p className="text-sm text-slate-600 mb-4">
            将所有数据导出为 JSON 文件，用于备份或迁移到其他浏览器。
          </p>
          <button
            onClick={handleExport}
            className="w-full bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md font-medium transition-colors"
          >
            导出备份
          </button>
        </div>

        {/* Clear Cache */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-3">
            <RefreshCw className="h-5 w-5 text-blue-600" />
            <h3 className="font-bold text-slate-900">清理缓存</h3>
          </div>
          <p className="text-sm text-slate-600 mb-4">
            清除会话缓存，解决数据不更新的问题。不会删除帖子和用户数据。
          </p>
          <button
            onClick={handleClearCache}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md font-medium transition-colors"
          >
            清理缓存
          </button>
        </div>
      </div>

      {/* Import */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-3">
          <Upload className="h-5 w-5 text-indigo-600" />
          <h3 className="font-bold text-slate-900">导入数据</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">
          从备份文件导入数据。警告：这会覆盖当前所有数据！
        </p>
        <textarea
          value={importData}
          onChange={(e) => setImportData(e.target.value)}
          placeholder="将导出的 JSON 数据粘贴到这里..."
          className="w-full h-32 px-3 py-2 border border-slate-300 rounded-md mb-3 text-sm font-mono"
        />
        <button
          onClick={handleImport}
          className="w-full bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-md font-medium transition-colors"
        >
          导入数据
        </button>
      </div>

      {/* Danger Zone */}
      <div className="bg-white rounded-lg shadow-sm border border-red-200 p-6">
        <div className="flex items-center gap-3 mb-3">
          <Trash2 className="h-5 w-5 text-red-600" />
          <h3 className="font-bold text-red-900">危险区域</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">
          清空所有数据，包括用户、帖子、评论等。此操作不可恢复！
        </p>
        {!showConfirm ? (
          <button
            onClick={() => setShowConfirm(true)}
            className="w-full bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md font-medium transition-colors"
          >
            清空所有数据
          </button>
        ) : (
          <div className="space-y-3">
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
              ⚠️ 确定要清空所有数据吗？此操作无法撤销！
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirm(false)}
                className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 px-4 py-2 rounded-md font-medium transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleClearAll}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md font-medium transition-colors"
              >
                确认清空
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Back Button */}
      <div className="text-center">
        <button
          onClick={() => navigate('/')}
          className="text-indigo-600 hover:text-indigo-800 font-medium"
        >
          ← 返回首页
        </button>
      </div>
    </div>
  );
};
