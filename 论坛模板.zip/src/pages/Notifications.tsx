import React from 'react';
import { useForum } from '../context/ForumContext';
import { useAuth } from '../context/AuthContext';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { Bell, CheckCircle } from 'lucide-react';

export const Notifications: React.FC = () => {
  const { user } = useAuth();
  const { notifications, markNotificationRead } = useForum();

  if (!user) return <div className="text-center py-12">请先登录</div>;

  const myNotifications = notifications
    .filter(n => n.userId === user.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
        <Bell className="h-6 w-6" />
        通知中心
      </h1>
      
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        {myNotifications.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            暂无通知
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {myNotifications.map(notif => (
              <div 
                key={notif.id} 
                className={`p-4 hover:bg-slate-50 transition-colors ${notif.isRead ? 'opacity-60' : 'bg-indigo-50/30'}`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                     <p className="text-slate-800 font-medium mb-1">{notif.message}</p>
                     <div className="flex items-center gap-2 text-xs text-slate-500">
                       <span>{format(new Date(notif.createdAt), 'yyyy-MM-dd HH:mm')}</span>
                       {notif.link && (
                         <Link to={notif.link} className="text-indigo-600 hover:underline">
                           查看详情
                         </Link>
                       )}
                     </div>
                  </div>
                  {!notif.isRead && (
                    <button 
                      onClick={() => markNotificationRead(notif.id)}
                      className="text-slate-400 hover:text-indigo-600"
                      title="标记为已读"
                    >
                      <CheckCircle className="h-5 w-5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
