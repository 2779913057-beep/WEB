import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForum } from '../context/ForumContext';
import { useAuth } from '../context/AuthContext';
import BlockEditor from '../components/BlockEditor';
import { ContentBlock } from '../types';
import { Image, Gift, Upload } from 'lucide-react';

export const CreateThread: React.FC = () => {
  const { categoryId, threadId } = useParams<{ categoryId?: string; threadId?: string }>();
  const { categories, createThread, updateThread, getThread } = useForum();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [blocks, setBlocks] = useState<ContentBlock[]>([]);
  
  // 封面图片
  const [coverImage, setCoverImage] = useState('');
  
  // 隐藏内容选项
  const [hideType, setHideType] = useState<'none' | 'reply' | 'pay'>('none');
  const [price, setPrice] = useState<number>(0);
  const [hiddenContent, setHiddenContent] = useState('');
  
  // 回帖奖励设置
  const [enableReward, setEnableReward] = useState(false);
  const [rewardBudget, setRewardBudget] = useState<number>(100);
  const [rewardPerReply, setRewardPerReply] = useState<number>(10);
  const [rewardProbability, setRewardProbability] = useState<number>(50);
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load existing data if editing
  useEffect(() => {
    if (threadId) {
      const thread = getThread(threadId);
      if (thread) {
        setTitle(thread.title);
        setCoverImage(thread.coverImage || '');
        setHideType(thread.hideType);
        setPrice(thread.price || 0);
        setHiddenContent(thread.hiddenContent || '');
        
        if (thread.rewardConfig) {
          setEnableReward(thread.rewardConfig.enabled);
          setRewardBudget(thread.rewardConfig.totalBudget);
          setRewardPerReply(thread.rewardConfig.amountPerReward);
          setRewardProbability(thread.rewardConfig.probability);
        }
        
        if (thread.blocks) {
          setBlocks(thread.blocks);
        }
      }
    }
  }, [threadId, getThread]);

  const category = categoryId ? categories.find(c => c.id === categoryId) : (threadId ? categories.find(c => c.id === getThread(threadId)?.categoryId) : undefined);

  if (!category) return <div className="text-center py-10 text-red-500">找不到该板块</div>;
  if (!user) return <div className="text-center py-10 text-red-500">请先登录后再发帖</div>;

  // 处理封面图片上传
  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 512 * 1024) {
        alert('封面图片大小不能超过 512KB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoverImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || blocks.length === 0) {
      alert('请填写标题和内容');
      return;
    }

    // 验证奖励设置
    if (enableReward) {
      if (rewardBudget < rewardPerReply) {
        alert('奖励预算必须大于单次奖励金额');
        return;
      }
      if (user.points < rewardBudget) {
        alert(`您的积分不足。当前积分: ${user.points}, 需要: ${rewardBudget}`);
        return;
      }
    }

    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const options = {
      coverImage: coverImage || undefined,
      hideType,
      price: hideType === 'pay' ? price : undefined,
      hiddenContent: hideType !== 'none' ? hiddenContent : undefined,
      rewardConfig: enableReward ? {
        enabled: true,
        totalBudget: rewardBudget,
        remainingBudget: rewardBudget,
        amountPerReward: rewardPerReply,
        probability: rewardProbability
      } : undefined
    };
    
    if (threadId) {
      updateThread(threadId, title, blocks, options);
      navigate(`/thread/${threadId}`);
    } else if (category) {
      createThread(category.id, title, blocks, user, options);
      navigate(`/category/${category.id}`);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">
        {threadId ? '编辑帖子' : `在 ${category.name} 发布新帖`}
      </h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* 标题 */}
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-slate-700 mb-1">
            标题 <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-4 py-2 border"
            placeholder="请输入帖子标题..."
            required
          />
        </div>

        {/* ========== 封面图片上传 ========== */}
        <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
          <div className="flex items-center gap-2 mb-3">
            <Image className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-blue-900">帖子封面</h3>
            <span className="text-xs text-blue-600 bg-blue-100 px-2 py-1 rounded">推荐上传</span>
          </div>
          
          <div className="space-y-3">
            {coverImage ? (
              <div className="relative">
                <img 
                  src={coverImage} 
                  alt="封面预览" 
                  className="w-full h-48 object-cover rounded-lg border"
                />
                <button
                  type="button"
                  onClick={() => setCoverImage('')}
                  className="absolute top-2 right-2 bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
                >
                  删除封面
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-blue-300 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors">
                <Upload className="w-10 h-10 text-blue-400 mb-2" />
                <span className="text-blue-600 font-medium">点击上传封面图片</span>
                <span className="text-blue-400 text-sm mt-1">支持 JPG、PNG、GIF，最大 512KB</span>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/gif"
                  onChange={handleCoverUpload}
                  className="hidden"
                />
              </label>
            )}
            
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-500">或输入图片链接：</span>
              <input
                type="url"
                value={coverImage.startsWith('data:') ? '' : coverImage}
                onChange={(e) => setCoverImage(e.target.value)}
                placeholder="https://example.com/image.jpg"
                className="flex-1 rounded border-slate-300 text-sm px-3 py-1 border"
              />
            </div>
          </div>
        </div>

        {/* 内容编辑器 */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            内容 <span className="text-red-500">*</span>
          </label>
          <BlockEditor 
            blocks={blocks} 
            onChange={setBlocks} 
          />
        </div>

        {/* ========== 回帖奖励设置 ========== */}
        <div className="bg-orange-50 p-4 rounded-lg border-2 border-orange-200">
          <div className="flex items-center gap-2 mb-3">
            <Gift className="w-5 h-5 text-orange-600" />
            <h3 className="font-bold text-orange-900">回帖奖励设置</h3>
            <span className="text-xs text-orange-600 bg-orange-100 px-2 py-1 rounded">可选</span>
          </div>
          
          <div className="space-y-4">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={enableReward}
                onChange={(e) => setEnableReward(e.target.checked)}
                className="w-5 h-5 text-orange-600 rounded focus:ring-orange-500"
              />
              <span className="text-slate-700 font-medium">启用回帖抽奖奖励</span>
              <span className="text-sm text-slate-500">（您当前积分: {user.points}）</span>
            </label>
            
            {enableReward && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-white rounded-lg border border-orange-200">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    奖励总预算 (积分)
                  </label>
                  <input
                    type="number"
                    min="10"
                    max={user.points}
                    value={rewardBudget}
                    onChange={(e) => setRewardBudget(parseInt(e.target.value) || 0)}
                    className="w-full rounded border-slate-300 text-sm px-3 py-2 border"
                  />
                  <p className="text-xs text-slate-500 mt-1">将从您的积分中扣除</p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    每次中奖金额 (积分)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={rewardPerReply}
                    onChange={(e) => setRewardPerReply(parseInt(e.target.value) || 0)}
                    className="w-full rounded border-slate-300 text-sm px-3 py-2 border"
                  />
                  <p className="text-xs text-slate-500 mt-1">中奖者获得的积分</p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    中奖概率 (%)
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="100"
                    value={rewardProbability}
                    onChange={(e) => setRewardProbability(parseInt(e.target.value) || 0)}
                    className="w-full rounded border-slate-300 text-sm px-3 py-2 border"
                  />
                  <p className="text-xs text-slate-500 mt-1">10% - 100%</p>
                </div>
                
                <div className="md:col-span-3 p-3 bg-orange-100 rounded text-sm text-orange-800">
                  <strong>奖励说明：</strong> 用户回帖时有 {rewardProbability}% 的概率中奖，
                  中奖可获得 {rewardPerReply} 积分。预算 {rewardBudget} 积分，
                  预计可发放 {Math.floor(rewardBudget / rewardPerReply)} 次奖励。
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 隐藏内容选项 */}
        <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-4">
          <h3 className="font-bold text-slate-900">高级选项 - 内容可见性</h3>
          
          <div className="space-y-2">
            <div className="flex gap-4 flex-wrap">
              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="radio" 
                  name="hideType" 
                  checked={hideType === 'none'} 
                  onChange={() => setHideType('none')}
                  className="text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-sm text-slate-700">公开可见</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="radio" 
                  name="hideType" 
                  checked={hideType === 'reply'} 
                  onChange={() => setHideType('reply')}
                  className="text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-sm text-slate-700">回复后可见</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="radio" 
                  name="hideType" 
                  checked={hideType === 'pay'} 
                  onChange={() => setHideType('pay')}
                  className="text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-sm text-slate-700">付积分可见</span>
              </label>
            </div>
          </div>

          {hideType === 'pay' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">解锁价格 (积分)</label>
              <input 
                type="number" 
                min="1"
                value={price}
                onChange={(e) => setPrice(parseInt(e.target.value) || 0)}
                className="w-full max-w-xs rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              />
            </div>
          )}

          {hideType !== 'none' && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                隐藏内容 (链接、提取码等)
              </label>
              <textarea
                value={hiddenContent}
                onChange={(e) => setHiddenContent(e.target.value)}
                className="w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 h-24"
                placeholder="在此输入需要隐藏的内容，如网盘链接、提取码等..."
              />
            </div>
          )}
        </div>

        {/* 提交按钮 */}
        <div className="flex justify-end gap-4 pt-4 border-t">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="px-4 py-2 border border-slate-300 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            取消
          </button>
          <button
            type="submit"
            disabled={isSubmitting || !title.trim() || blocks.length === 0}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-md font-medium disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? '发布中...' : (threadId ? '保存修改' : '发布帖子')}
          </button>
        </div>
      </form>
    </div>
  );
};
