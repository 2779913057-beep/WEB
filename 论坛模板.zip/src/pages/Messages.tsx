import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useForum } from '../context/ForumContext';
import { useAuth } from '../context/AuthContext';
import { format } from 'date-fns';
import { Mail, Send, Users, FileText, Bell, Lock } from 'lucide-react';

export const Messages: React.FC = () => {
  const { user, getAllUsers, isMutualFollow } = useAuth();
  const { messages, sendMessage, followActivities, threads } = useForum();
  const [recipientId, setRecipientId] = useState('');
  const [content, setContent] = useState('');
  const [msgSent, setMsgSent] = useState(false);
  const [activeTab, setActiveTab] = useState<'inbox' | 'following'>('inbox');

  if (!user) return <div className="text-center py-12">请先登录</div>;

  const allUsers = getAllUsers();
  
  // 只显示互相关注的用户
  const mutualFollowUsers = allUsers.filter(u => u.id !== user.id && isMutualFollow(u.id));
  
  const myMessages = messages
    .filter(m => m.receiverId === user.id || m.senderId === user.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // 获取关注者的动态（新发帖）
  const myFollows = user.follows || [];
  const followingActivities = followActivities
    .filter(a => myFollows.includes(a.userId))
    .slice(0, 20);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientId || !content.trim()) return;

    // 检查是否互相关注
    if (!isMutualFollow(recipientId)) {
      alert('只能给互相关注的用户发送私信');
      return;
    }

    const recipient = allUsers.find(u => u.id === recipientId);
    if (!recipient) return;

    sendMessage(user.id, user.nickname || user.username, recipient.id, content);
    setContent('');
    setMsgSent(true);
    setTimeout(() => setMsgSent(false), 3000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('inbox')}
          className={`flex items-center gap-2 px-6 py-3 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'inbox'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Mail className="h-4 w-4" />
          私信
        </button>
        <button
          onClick={() => setActiveTab('following')}
          className={`flex items-center gap-2 px-6 py-3 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'following'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Users className="h-4 w-4" />
          关注动态
        </button>
      </div>

      {activeTab === 'inbox' ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Send Message Form */}
          <div className="md:col-span-1 space-y-4">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Send className="h-5 w-5" />
                发送私信
              </h2>
              
              {mutualFollowUsers.length === 0 ? (
                <div className="text-center py-6">
                  <Lock className="h-10 w-10 text-slate-300 mx-auto mb-3" />
                  <p className="text-sm text-slate-500 mb-2">
                    只能给互相关注的用户发送私信
                  </p>
                  <p className="text-xs text-slate-400">
                    先去关注其他用户，等对方关注你后即可私信
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSend} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      收信人 <span className="text-xs text-slate-400">(互相关注)</span>
                    </label>
                    <select 
                      value={recipientId}
                      onChange={e => setRecipientId(e.target.value)}
                      className="block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                      required
                    >
                      <option value="">选择用户...</option>
                      {mutualFollowUsers.map(u => (
                        <option key={u.id} value={u.id}>
                          {u.nickname || u.username} {u.role === 'admin' ? '(管理员)' : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">内容</label>
                    <textarea
                      value={content}
                      onChange={e => setContent(e.target.value)}
                      rows={4}
                      className="block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                      placeholder="写点什么..."
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-md text-sm font-medium transition-colors"
                  >
                    发送
                  </button>
                  {msgSent && <p className="text-green-600 text-sm text-center">发送成功！</p>}
                </form>
              )}
            </div>
          </div>

          {/* Inbox */}
          <div className="md:col-span-2 space-y-4">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 min-h-[500px]">
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Mail className="h-5 w-5" />
                我的信箱
              </h2>
              
              {myMessages.length === 0 ? (
                <div className="text-center text-slate-500 py-12">暂无消息</div>
              ) : (
                <div className="space-y-4">
                  {myMessages.map(msg => {
                    const isMe = msg.senderId === user.id;
                    const sender = allUsers.find(u => u.id === msg.senderId);
                    return (
                      <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                        <div className={`max-w-[80%] rounded-lg p-3 ${isMe ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-800'}`}>
                          <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                        </div>
                        <div className="flex items-center gap-2 mt-1 px-1">
                          {!isMe && sender && (
                            <Link to={`/profile/${sender.id}`} className="text-xs text-indigo-600 hover:underline">
                              {msg.senderName}
                            </Link>
                          )}
                          <span className="text-xs text-slate-400">
                            {isMe ? '我' : ''} • {format(new Date(msg.createdAt), 'MM-dd HH:mm')}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Following Activity Tab */
        <div className="bg-white rounded-lg shadow-sm border border-slate-200">
          <div className="p-6 border-b border-slate-200">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Bell className="h-5 w-5" />
              关注者的最新动态
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              您关注了 {myFollows.length} 个用户
            </p>
          </div>
          
          {followingActivities.length === 0 ? (
            <div className="p-12 text-center">
              <Users className="h-16 w-16 text-slate-200 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-700 mb-2">
                {myFollows.length === 0 ? '您还没有关注任何人' : '关注的用户暂无新动态'}
              </h3>
              <p className="text-slate-500 mb-4">
                关注其他用户后，他们的新帖子会显示在这里
              </p>
              <Link 
                to="/" 
                className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-md font-medium"
              >
                去发现用户
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-slate-200">
              {followingActivities.map(activity => {
                const activityUser = allUsers.find(u => u.id === activity.userId);
                const thread = threads.find(t => t.id === activity.threadId);
                if (!activityUser || !thread) return null;
                
                return (
                  <div key={activity.id} className="p-4 hover:bg-slate-50 transition-colors">
                    <div className="flex items-start gap-4">
                      <Link to={`/profile/${activityUser.id}`}>
                        <img 
                          src={activityUser.avatar} 
                          alt={activityUser.nickname || activityUser.username}
                          className="w-10 h-10 rounded-full bg-slate-200"
                        />
                      </Link>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Link 
                            to={`/profile/${activityUser.id}`}
                            className="font-medium text-slate-900 hover:text-indigo-600"
                          >
                            {activityUser.nickname || activityUser.username}
                          </Link>
                          <span className="text-slate-500">发布了新帖子</span>
                        </div>
                        <Link 
                          to={`/thread/${activity.threadId}`}
                          className="mt-1 flex items-center gap-2 text-indigo-600 hover:underline"
                        >
                          <FileText className="h-4 w-4" />
                          {activity.threadTitle}
                        </Link>
                        <div className="mt-1 text-xs text-slate-400">
                          {format(new Date(activity.createdAt), 'yyyy年MM月dd日 HH:mm')}
                        </div>
                      </div>
                      {thread.coverImage && (
                        <div className="flex-shrink-0 w-20 h-14 rounded overflow-hidden bg-slate-100">
                          <img 
                            src={thread.coverImage} 
                            alt={thread.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
