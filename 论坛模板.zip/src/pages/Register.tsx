import React, { useState } from 'react';
import { useAuth, RegisterData } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { User, Lock, Mail, Phone, HelpCircle, FileText, Smile, Gift } from 'lucide-react';

export const Register: React.FC = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState<RegisterData>({
    username: '',
    password: '',
    nickname: '',
    gender: 'male',
    phone: '',
    email: '',
    securityQuestion: '',
    securityAnswer: '',
    inviteCode: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (formData.username.length < 3) {
      setError('用户名至少需要3个字符');
      return;
    }
    if (!formData.password || formData.password.length < 6) {
      setError('密码至少需要6个字符');
      return;
    }

    setLoading(true);
    
    const success = await register(formData);
    if (success) {
      navigate('/');
    } else {
      setError('用户名已存在');
    }
    setLoading(false);
  };

  return (
    <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full space-y-8 bg-white p-8 rounded-xl shadow-sm border border-slate-200">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-slate-900">
            加入 SudoCG 社区
          </h2>
          <p className="mt-2 text-center text-sm text-slate-600">
            已有账户？{' '}
            <Link to="/login" className="font-medium text-indigo-600 hover:text-indigo-500">
              登录
            </Link>
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Username */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700">用户名</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  name="username"
                  type="text"
                  required
                  className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 rounded-md border p-2"
                  placeholder="登录账号"
                  value={formData.username}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* Password */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700">密码</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  name="password"
                  type="password"
                  required
                  className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 rounded-md border p-2"
                  placeholder="设置您的密码"
                  value={formData.password}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* Nickname */}
            <div>
              <label className="block text-sm font-medium text-slate-700">昵称</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Smile className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  name="nickname"
                  type="text"
                  required
                  className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 rounded-md border p-2"
                  placeholder="社区显示名称"
                  value={formData.nickname}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* Gender */}
            <div>
              <label className="block text-sm font-medium text-slate-700">性别</label>
              <select
                name="gender"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md border"
                value={formData.gender}
                onChange={handleChange}
              >
                <option value="male">男</option>
                <option value="female">女</option>
                <option value="other">其他</option>
              </select>
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm font-medium text-slate-700">手机号</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  name="phone"
                  type="tel"
                  required
                  className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 rounded-md border p-2"
                  placeholder="联系电话"
                  value={formData.phone}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-slate-700">邮箱</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  name="email"
                  type="email"
                  required
                  className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 rounded-md border p-2"
                  placeholder="email@example.com"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* Security Question */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700">密保问题 (用于找回密码)</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <HelpCircle className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  name="securityQuestion"
                  type="text"
                  required
                  className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 rounded-md border p-2"
                  placeholder="例如：我的第一只宠物叫什么？"
                  value={formData.securityQuestion}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* Security Answer */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700">密保答案</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FileText className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  name="securityAnswer"
                  type="text"
                  required
                  className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 rounded-md border p-2"
                  placeholder="您的答案"
                  value={formData.securityAnswer}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* Invite Code */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700">邀请码 (可选)</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Gift className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  name="inviteCode"
                  type="text"
                  className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-slate-300 rounded-md border p-2"
                  placeholder="填写邀请码，双方均可获得积分奖励"
                  value={formData.inviteCode || ''}
                  onChange={handleChange}
                />
              </div>
              <div className="mt-2 p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
                <p className="text-sm font-medium text-green-800">🎁 邀请奖励机制</p>
                <ul className="mt-1 text-xs text-green-700 space-y-1">
                  <li>• 填写有效邀请码，<strong>您将获得额外 30 积分</strong></li>
                  <li>• 同时<strong>邀请人将获得 50 积分</strong>奖励</li>
                  <li>• 没有邀请码也可以注册，初始积分为 100</li>
                </ul>
              </div>
            </div>
          </div>

          {error && (
            <div className="text-red-500 text-sm text-center">{error}</div>
          )}

          <div>
            <button
              type="submit"
              disabled={loading}
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
            >
              {loading ? '注册中...' : '注册'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
