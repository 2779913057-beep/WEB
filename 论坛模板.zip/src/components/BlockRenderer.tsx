import React from 'react';
import { ContentBlock } from '../types';
import { processContent } from '../utils/contentProcessor';

interface BlockRendererProps {
  content?: string;
  blocks?: ContentBlock[];
}

const BlockRenderer: React.FC<BlockRendererProps> = ({ content, blocks: propBlocks }) => {
  let blocks: ContentBlock[] = propBlocks || [];
  let isLegacyHtml = false;

  if (!propBlocks && content) {
    try {
      // Try to parse if it looks like JSON array
      if (content.trim().startsWith('[')) {
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed) && parsed.length > 0 && 'type' in parsed[0]) {
          blocks = parsed;
        } else {
          isLegacyHtml = true;
        }
      } else {
        isLegacyHtml = true;
      }
    } catch (e) {
      isLegacyHtml = true;
    }
  }

  if (isLegacyHtml && content) {
    return (
      <div 
        className="prose max-w-none ql-editor"
        dangerouslySetInnerHTML={{ __html: processContent(content) }}
      />
    );
  }

  return (
    <div className="space-y-6">
      {blocks.map((block) => {
        switch (block.type) {
          case 'header':
            return (
              <h2 key={block.id} className="text-2xl font-bold text-gray-900 border-b pb-2 mb-4">
                {block.value}
              </h2>
            );
          case 'text':
            return (
              <div key={block.id} className="prose max-w-none whitespace-pre-wrap text-gray-800 leading-relaxed">
                {block.value}
              </div>
            );
          case 'image':
            return (
              <div key={block.id} className="flex justify-center">
                <img 
                  src={block.value} 
                  alt="Post content" 
                  className="max-w-full rounded-lg shadow-sm"
                  loading="lazy"
                />
              </div>
            );
          case 'video':
            const bvidMatch = block.value.match(/(BV[a-zA-Z0-9]+)/);
            let embedSrc = '';
            
            if (bvidMatch) {
                embedSrc = `//player.bilibili.com/player.html?bvid=${bvidMatch[1]}&page=1&high_quality=1&danmaku=0`;
            } else if (block.value.includes('iframe') && block.value.includes('src="')) {
                const srcMatch = block.value.match(/src="([^"]+)"/);
                if (srcMatch) embedSrc = srcMatch[1];
            } else if (block.value.startsWith('http')) {
                if (block.value.includes('bilibili.com/video/')) {
                    const match = block.value.match(/\/video\/(BV[a-zA-Z0-9]+)/);
                    if (match) embedSrc = `//player.bilibili.com/player.html?bvid=${match[1]}&page=1&high_quality=1&danmaku=0`;
                }
            }

            if (embedSrc) {
               return (
                  <div key={block.id} className="w-full aspect-video bg-black rounded-lg overflow-hidden my-4 shadow-sm">
                    <iframe
                      src={embedSrc}
                      scrolling="no"
                      frameBorder="0"
                      allowFullScreen={true}
                      className="w-full h-full"
                    ></iframe>
                  </div>
               );
            }
            
            return (
                <div key={block.id} className="text-red-500 text-sm p-2 bg-red-50 rounded">
                    无效的视频链接或代码
                </div>
            );

          default:
            return null;
        }
      })}
    </div>
  );
};

export default BlockRenderer;
