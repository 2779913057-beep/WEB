import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, RedemptionCode } from '../types';
import { encryptData, decryptData } from '../utils/crypto';
import { v4 as uuidv4 } from 'uuid';
import { format, addDays, isAfter } from 'date-fns';

export interface RegisterData {
  username: string;
  nickname: string;
  gender: 'male' | 'female' | 'other';
  phone: string;
  email: string;
  securityQuestion: string;
  securityAnswer: string;
  password?: string;
  inviteCode?: string; // Optional invite code
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<{ success: boolean; message?: string }>;
  register: (data: RegisterData) => Promise<boolean>;
  logout: () => void;
  updateUser: (updatedUser: User) => void;
  getAllUsers: () => User[];
  deleteUser: (userId: string) => void;
  updateUserStatus: (userId: string, isBanned: boolean) => void;
  resetUserPassword: (userId: string) => void;
  
  updateAvatar: (base64: string) => void;
  topUpPoints: (amount: number) => void;
  addPoints: (userId: string, amount: number) => void;
  transferPoints: (fromUserId: string, toUserId: string, amount: number) => boolean;
  purchaseThread: (threadId: string, price: number, authorId: string) => boolean;
  changePassword: (securityAnswer: string, newPassword: string) => Promise<{ success: boolean; message: string }>;
  followUser: (targetUserId: string) => void;
  unfollowUser: (targetUserId: string) => void;
  isFollowing: (targetUserId: string) => boolean;
  isMutualFollow: (targetUserId: string) => boolean;
  
  // Favorites
  addFavorite: (threadId: string) => void;
  removeFavorite: (threadId: string) => void;
  isFavorite: (threadId: string) => boolean;
  
  // Redemption Codes
  redemptionCodes: RedemptionCode[];
  generateRedemptionCode: (points: number) => string;
  redeemCode: (code: string) => { success: boolean; message: string; points?: number };
  
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Generate a unique invite code from user ID
const generateInviteCode = (userId: string): string => {
  return 'INV' + userId.slice(0, 6).toUpperCase();
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [redemptionCodes, setRedemptionCodes] = useState<RedemptionCode[]>([]);

  useEffect(() => {
    // Initialize Admin if not exists
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    let users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    
    if (!users.find(u => u.username === 'admin')) {
      const adminId = 'admin-seed-id';
      const adminUser: User = {
        id: adminId,
        username: 'admin',
        password: 'admin123',
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=admin`,
        role: 'admin',
        points: 99999,
        purchasedThreads: [],
        favorites: [],
        createdAt: new Date().toISOString(),
        isBanned: false,
        nickname: '超级管理员',
        gender: 'other',
        securityQuestion: 'Default',
        securityAnswer: 'admin',
        passwordChangeCount: 0,
        lastPasswordChangeDate: '',
        inviteCode: generateInviteCode(adminId),
        inviteCount: 0
      };
      users.push(adminUser);
      localStorage.setItem('forum_users', encryptData(users));
      console.log('Admin user seeded');
    }

    // Load Codes
    const storedCodes = localStorage.getItem('forum_redemption_codes');
    if (storedCodes) {
      setRedemptionCodes(decryptData<RedemptionCode[]>(storedCodes) || []);
    }

    // Check for active session (7-day login)
    const storedSession = localStorage.getItem('forum_session');
    if (storedSession) {
      try {
        const session = decryptData<{ userId: string; expiry: string }>(storedSession);
        if (session && session.expiry) {
          const expiryDate = new Date(session.expiry);
          if (isAfter(expiryDate, new Date())) {
            // Session still valid
            const currentUser = users.find(u => u.id === session.userId);
            if (currentUser && !currentUser.isBanned) {
              setUser(currentUser);
            } else {
              localStorage.removeItem('forum_session');
            }
          } else {
            // Session expired
            localStorage.removeItem('forum_session');
          }
        }
      } catch (e) {
        localStorage.removeItem('forum_session');
      }
    }
    
    setLoading(false);
  }, []);

  const saveUser = (u: User) => {
    setUser(u);
    // Save session with 7-day expiry
    const session = {
      userId: u.id,
      expiry: addDays(new Date(), 7).toISOString()
    };
    localStorage.setItem('forum_session', encryptData(session));
    
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    const updatedUsers = users.map(user => user.id === u.id ? u : user);
    localStorage.setItem('forum_users', encryptData(updatedUsers));
  };

  const saveCodes = (codes: RedemptionCode[]) => {
    setRedemptionCodes(codes);
    localStorage.setItem('forum_redemption_codes', encryptData(codes));
  };

  const login = async (username: string, password: string): Promise<{ success: boolean; message?: string }> => {
    await new Promise(resolve => setTimeout(resolve, 500));

    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    
    const foundUser = users.find(u => u.username === username);
    
    if (foundUser) {
      if (foundUser.password !== password) {
        return { success: false, message: '账号或密码错误' };
      }
      if (foundUser.isBanned) {
        return { success: false, message: '此账号已被封禁' };
      }
      saveUser(foundUser); 
      return { success: true };
    }
    return { success: false, message: '账号或密码错误' };
  };

  const register = async (data: RegisterData): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 500));

    // Username Validation: Alphanumeric only
    const usernameRegex = /^[a-zA-Z0-9]+$/;
    if (!usernameRegex.test(data.username)) {
      alert('用户名只能包含字母和数字');
      return false;
    }

    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];

    if (users.find(u => u.username === data.username)) {
      return false; 
    }

    const newUserId = uuidv4();
    
    // Check if invite code is valid
    let inviterUser: User | undefined;
    if (data.inviteCode) {
      inviterUser = users.find(u => u.inviteCode === data.inviteCode);
    }

    // Calculate new user points: base 100 + 30 bonus if using valid invite code
    const newUserPoints = inviterUser ? 130 : 100;

    const newUser: User = {
      id: newUserId,
      username: data.username,
      password: data.password || '123456',
      nickname: data.nickname,
      gender: data.gender,
      phone: data.phone,
      email: data.email,
      securityQuestion: data.securityQuestion,
      securityAnswer: data.securityAnswer,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${data.username}`,
      role: data.username === 'admin' ? 'admin' : 'user',
      points: newUserPoints, // 100 base + 30 if invited
      purchasedThreads: [],
      favorites: [],
      createdAt: new Date().toISOString(),
      isBanned: false,
      passwordChangeCount: 0,
      lastPasswordChangeDate: '',
      inviteCode: generateInviteCode(newUserId),
      invitedBy: inviterUser?.id,
      inviteCount: 0
    };

    let updatedUsers = [...users, newUser];

    // Reward inviter with 50 points
    if (inviterUser) {
      updatedUsers = updatedUsers.map(u => {
        if (u.id === inviterUser!.id) {
          return {
            ...u,
            points: (u.points || 0) + 50,
            inviteCount: (u.inviteCount || 0) + 1
          };
        }
        return u;
      });
    }

    localStorage.setItem('forum_users', encryptData(updatedUsers));
    
    setUser(newUser);
    // Save session with 7-day expiry
    const session = {
      userId: newUser.id,
      expiry: addDays(new Date(), 7).toISOString()
    };
    localStorage.setItem('forum_session', encryptData(session));
    
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('forum_session');
  };

  const updateUser = (updatedUser: User) => {
    saveUser(updatedUser);
  };

  const getAllUsers = (): User[] => {
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    return storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
  };

  const deleteUser = (userId: string) => {
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    const updatedUsers = users.filter(u => u.id !== userId);
    localStorage.setItem('forum_users', encryptData(updatedUsers));
    
    if (user?.id === userId) {
      logout();
    }
  };

  const updateUserStatus = (userId: string, isBanned: boolean) => {
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    const updatedUsers = users.map(u => u.id === userId ? { ...u, isBanned } : u);
    localStorage.setItem('forum_users', encryptData(updatedUsers));
    if (user?.id === userId && isBanned) {
      logout();
    }
  };

  const resetUserPassword = (userId: string) => {
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    const updatedUsers = users.map(u => u.id === userId ? { ...u, password: '123456' } : u);
    localStorage.setItem('forum_users', encryptData(updatedUsers));
    alert('密码已重置为: 123456');
  };

  const updateAvatar = (base64: string) => {
    if (!user) return;
    const updatedUser = { ...user, avatar: base64 };
    saveUser(updatedUser);
  };

  const topUpPoints = (amount: number) => {
    if (!user) return;
    const updatedUser = { ...user, points: (user.points || 0) + amount };
    saveUser(updatedUser);
  };

  const addPoints = (userId: string, amount: number) => {
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    
    let updatedUser: User | null = null;
    const updatedUsers = users.map(u => {
      if (u.id === userId) {
        updatedUser = { ...u, points: (u.points || 0) + amount };
        return updatedUser;
      }
      return u;
    });
    
    localStorage.setItem('forum_users', encryptData(updatedUsers));
    if (user && user.id === userId && updatedUser) {
      saveUser(updatedUser);
    }
  };

  const transferPoints = (fromUserId: string, toUserId: string, amount: number): boolean => {
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    
    const fromUser = users.find(u => u.id === fromUserId);
    const toUser = users.find(u => u.id === toUserId);
    
    if (!fromUser || !toUser) return false;
    if ((fromUser.points || 0) < amount) return false;
    
    const updatedFromUser = { ...fromUser, points: (fromUser.points || 0) - amount };
    const updatedToUser = { ...toUser, points: (toUser.points || 0) + amount };
    
    const updatedUsers = users.map(u => {
      if (u.id === fromUserId) return updatedFromUser;
      if (u.id === toUserId) return updatedToUser;
      return u;
    });
    
    localStorage.setItem('forum_users', encryptData(updatedUsers));
    
    if (user && user.id === fromUserId) saveUser(updatedFromUser);
    if (user && user.id === toUserId) saveUser(updatedToUser);
    
    return true;
  };

  const purchaseThread = (threadId: string, price: number, authorId: string): boolean => {
    if (!user) return false;
    if ((user.points || 0) < price) return false;
    if (user.purchasedThreads?.includes(threadId)) return true;

    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    
    const authorUser = users.find(u => u.id === authorId);
    
    const updatedBuyer = {
      ...user,
      points: (user.points || 0) - price,
      purchasedThreads: [...(user.purchasedThreads || []), threadId]
    };

    let updatedAuthor = authorUser;
    if (authorUser) {
      updatedAuthor = {
        ...authorUser,
        points: (authorUser.points || 0) + price
      };
    }

    const updatedUsers = users.map(u => {
      if (u.id === user.id) return updatedBuyer;
      if (authorUser && u.id === authorId) return updatedAuthor!;
      return u;
    });

    localStorage.setItem('forum_users', encryptData(updatedUsers));
    saveUser(updatedBuyer);
    
    return true;
  };

  const changePassword = async (securityAnswer: string, newPassword: string): Promise<{ success: boolean; message: string }> => {
    if (!user) return { success: false, message: 'Not logged in' };

    if (user.securityAnswer !== securityAnswer) {
      return { success: false, message: '密保答案错误' };
    }

    const today = format(new Date(), 'yyyy-MM-dd');
    let count = user.passwordChangeCount || 0;

    if (user.lastPasswordChangeDate !== today) {
      count = 0; 
    }

    if (count >= 2) {
      return { success: false, message: '今日修改密码次数已达上限 (2次)' };
    }

    const updatedUser: User = {
      ...user,
      password: newPassword,
      lastPasswordChangeDate: today,
      passwordChangeCount: count + 1
    };

    saveUser(updatedUser);
    return { success: true, message: '密码修改成功' };
  };

  const followUser = (targetUserId: string) => {
    if (!user) return;
    if (user.follows?.includes(targetUserId)) return;
    
    const updatedCurrentUser = {
      ...user,
      follows: [...(user.follows || []), targetUserId]
    };
    saveUser(updatedCurrentUser);
    
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    
    const updatedUsers = users.map(u => {
      if (u.id === targetUserId) {
        return { ...u, followers: [...(u.followers || []), user.id] };
      }
      return u;
    });
    localStorage.setItem('forum_users', encryptData(updatedUsers));
  };

  const unfollowUser = (targetUserId: string) => {
    if (!user) return;
    
    const updatedCurrentUser = {
      ...user,
      follows: (user.follows || []).filter(id => id !== targetUserId)
    };
    saveUser(updatedCurrentUser);
    
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    
    const updatedUsers = users.map(u => {
      if (u.id === targetUserId) {
        return { ...u, followers: (u.followers || []).filter(id => id !== user.id) };
      }
      return u;
    });
    localStorage.setItem('forum_users', encryptData(updatedUsers));
  };

  const isFollowing = (targetUserId: string): boolean => {
    if (!user) return false;
    return (user.follows || []).includes(targetUserId);
  };

  const isMutualFollow = (targetUserId: string): boolean => {
    if (!user) return false;
    const storedUsersEncrypted = localStorage.getItem('forum_users');
    const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
    const targetUser = users.find(u => u.id === targetUserId);
    if (!targetUser) return false;
    
    const iFollow = (user.follows || []).includes(targetUserId);
    const theyFollowMe = (targetUser.follows || []).includes(user.id);
    return iFollow && theyFollowMe;
  };

  const addFavorite = (threadId: string) => {
    if (!user) return;
    if (user.favorites?.includes(threadId)) return;
    
    const updatedUser = {
      ...user,
      favorites: [...(user.favorites || []), threadId]
    };
    saveUser(updatedUser);
  };

  const removeFavorite = (threadId: string) => {
    if (!user) return;
    
    const updatedUser = {
      ...user,
      favorites: (user.favorites || []).filter(id => id !== threadId)
    };
    saveUser(updatedUser);
  };

  const isFavorite = (threadId: string): boolean => {
    if (!user) return false;
    return (user.favorites || []).includes(threadId);
  };

  // Redemption Codes Logic
  const generateRedemptionCode = (points: number): string => {
    const code = uuidv4().slice(0, 8).toUpperCase();
    const newCode: RedemptionCode = {
      id: uuidv4(),
      code,
      points,
      isUsed: false,
      generatedBy: user?.username || 'admin',
      createdAt: new Date().toISOString()
    };
    saveCodes([...redemptionCodes, newCode]);
    return code;
  };

  const redeemCode = (codeInput: string): { success: boolean; message: string; points?: number } => {
    if (!user) return { success: false, message: '请先登录' };

    // Legacy support for demo
    if (codeInput === 'SUDO2024') {
       addPoints(user.id, 100);
       return { success: true, message: '兑换成功！已获得 100 积分', points: 100 };
    }

    const code = redemptionCodes.find(c => c.code === codeInput);
    if (!code) {
      return { success: false, message: '无效的兑换码' };
    }
    if (code.isUsed) {
      return { success: false, message: '该兑换码已被使用' };
    }

    // Mark as used
    const updatedCodes = redemptionCodes.map(c => 
      c.id === code.id ? { ...c, isUsed: true } : c
    );
    saveCodes(updatedCodes);

    // Add points
    addPoints(user.id, code.points);

    return { success: true, message: `兑换成功！已获得 ${code.points} 积分`, points: code.points };
  };

  useEffect(() => {
    if (user) {
      const today = format(new Date(), 'yyyy-MM-dd');
      if (user.lastLoginDate !== today) {
        const updatedUser = { 
          ...user, 
          points: (user.points || 0) + 10,
          lastLoginDate: today
        };
        saveUser(updatedUser);
        
        const storedUsersEncrypted = localStorage.getItem('forum_users');
        const users: User[] = storedUsersEncrypted ? decryptData<User[]>(storedUsersEncrypted) || [] : [];
        const updatedUsers = users.map(u => u.id === user.id ? updatedUser : u);
        localStorage.setItem('forum_users', encryptData(updatedUsers));
        
        console.log('Daily login reward +10 points');
      }
    }
  }, [user?.id]); 

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      register, 
      logout, 
      updateUser, 
      getAllUsers, 
      deleteUser, 
      updateUserStatus, 
      resetUserPassword, 
      updateAvatar,
      topUpPoints,
      addPoints,
      transferPoints,
      purchaseThread,
      changePassword,
      followUser,
      unfollowUser,
      isFollowing,
      isMutualFollow,
      addFavorite,
      removeFavorite,
      isFavorite,
      redemptionCodes,
      generateRedemptionCode,
      redeemCode,
      loading 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
