import React, { createContext, useContext, useState, useEffect } from 'react';
import { Category, Thread, Post, ContentBlock, Notification, Message, AutoModerationRules, FollowActivity } from '../types';
import { encryptData, decryptData } from '../utils/crypto';
import { v4 as uuidv4 } from 'uuid';
import { format, differenceInHours } from 'date-fns';

interface CreateThreadOptions {
  hideType: 'none' | 'reply' | 'pay';
  price?: number;
  hiddenContent?: string;
  coverImage?: string;
  rewardConfig?: {
    enabled: boolean;
    totalBudget: number;
    remainingBudget: number;
    amountPerReward: number;
    probability: number;
  };
}

interface ForumContextType {
  categories: Category[];
  threads: Thread[];
  posts: Post[];
  siteVisits: number;
  dailyVisits: number;
  notifications: Notification[];
  messages: Message[];
  bannedKeywords: string[];
  moderationRules: AutoModerationRules;
  followActivities: FollowActivity[];
  
  createThread: (categoryId: string, title: string, blocks: ContentBlock[], user: any, options?: CreateThreadOptions) => void;
  createPost: (threadId: string, content: string, user: any, parentId?: string) => void;
  addCategory: (name: string, description: string, icon: string, color: string) => void;
  deleteCategory: (categoryId: string) => void;
  deleteThread: (threadId: string) => void;
  restoreThread: (threadId: string) => void;
  permanentlyDeleteThread: (threadId: string) => void;
  updateThread: (threadId: string, title: string, blocks: ContentBlock[], options?: CreateThreadOptions) => void;
  toggleThreadVisibility: (threadId: string) => void;
  togglePinThread: (threadId: string) => void;
  toggleFeatureThread: (threadId: string) => void;
  
  // Social Features
  likeThread: (threadId: string, userId: string) => void;
  shareThread: (threadId: string) => void;
  likePost: (postId: string, userId: string) => void;
  tipThread: (threadId: string, userId: string, userName: string, amount: number) => boolean;
  tipPost: (postId: string, userId: string, userName: string, amount: number) => boolean;
  
  // Moderation
  approveThread: (threadId: string) => void;
  rejectThread: (threadId: string) => void;
  addBannedKeyword: (keyword: string) => void;
  removeBannedKeyword: (keyword: string) => void;
  updateModerationRules: (rules: AutoModerationRules) => void;
  
  // Messaging & Notifications
  sendMessage: (senderId: string, senderName: string, receiverId: string, content: string) => void;
  markNotificationRead: (notificationId: string) => void;
  
  getThreadsByCategory: (categoryId: string) => Thread[];
  getPostsByThread: (threadId: string) => Post[];
  getThread: (threadId: string) => Thread | undefined;
}

const ForumContext = createContext<ForumContextType | undefined>(undefined);

const DEFAULT_CATEGORIES: Category[] = [
  {
    id: 'cat_2d',
    name: '2D 美术资源',
    description: '分享笔刷、贴图和2D素材',
    icon: 'Palette',
    color: 'bg-blue-500'
  },
  {
    id: 'cat_3d',
    name: '3D 模型与资产',
    description: '模型、骨骼绑定和动画资源',
    icon: 'Box',
    color: 'bg-orange-500'
  },
  {
    id: 'cat_vfx',
    name: '特效与着色器',
    description: '粒子系统、Shader和视觉特效',
    icon: 'Sparkles',
    color: 'bg-purple-500'
  },
  {
    id: 'cat_tutorial',
    name: '教程与指南',
    description: '学习和传授美术技巧',
    icon: 'BookOpen',
    color: 'bg-green-500'
  },
  {
    id: 'cat_showcase',
    name: '作品展示',
    description: '展示你的最新创作',
    icon: 'Image',
    color: 'bg-pink-500'
  }
];

const DEFAULT_MODERATION_RULES: AutoModerationRules = {
  requireMediaReview: true,
  autoApproveTimeout: 24,
};

export const ForumProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [siteVisits, setSiteVisits] = useState<number>(0);
  const [dailyVisits, setDailyVisits] = useState<number>(0);
  const [bannedKeywords, setBannedKeywords] = useState<string[]>([]);
  const [moderationRules, setModerationRules] = useState<AutoModerationRules>(DEFAULT_MODERATION_RULES);
  const [followActivities, setFollowActivities] = useState<FollowActivity[]>([]);

  useEffect(() => {
    const loadData = () => {
      const storedCats = localStorage.getItem('forum_categories');
      const storedThreads = localStorage.getItem('forum_threads');
      const storedPosts = localStorage.getItem('forum_posts');
      const storedNotifs = localStorage.getItem('forum_notifications');
      const storedMsgs = localStorage.getItem('forum_messages');
      const storedVisits = localStorage.getItem('forum_site_visits');
      const storedDailyVisits = localStorage.getItem('forum_daily_visits');
      const storedLastVisitDate = localStorage.getItem('forum_last_visit_date');
      const storedKeywords = localStorage.getItem('forum_banned_keywords');
      const storedRules = localStorage.getItem('forum_moderation_rules');
      const storedActivities = localStorage.getItem('forum_follow_activities');

      if (storedCats) {
        setCategories(decryptData<Category[]>(storedCats) || DEFAULT_CATEGORIES);
      } else {
        setCategories(DEFAULT_CATEGORIES);
        localStorage.setItem('forum_categories', encryptData(DEFAULT_CATEGORIES));
      }

      if (storedThreads) {
        const loadedThreads = decryptData<Thread[]>(storedThreads) || [];
        // Ensure likes and shares exist
        const migratedThreads = loadedThreads.map(t => ({
          ...t,
          likes: t.likes || [],
          shares: t.shares || 0
        }));
        setThreads(migratedThreads);
      }
      
      if (storedPosts) {
        const loadedPosts = decryptData<Post[]>(storedPosts) || [];
        // Ensure likes exist
        const migratedPosts = loadedPosts.map(p => ({
          ...p,
          likes: p.likes || []
        }));
        setPosts(migratedPosts);
      }
      
      if (storedNotifs) {
        setNotifications(decryptData<Notification[]>(storedNotifs) || []);
      }
      
      if (storedMsgs) {
        setMessages(decryptData<Message[]>(storedMsgs) || []);
      }
      
      if (storedKeywords) {
        setBannedKeywords(decryptData<string[]>(storedKeywords) || []);
      }
      
      if (storedRules) {
        setModerationRules(decryptData<AutoModerationRules>(storedRules) || DEFAULT_MODERATION_RULES);
      }
      
      if (storedActivities) {
        setFollowActivities(decryptData<FollowActivity[]>(storedActivities) || []);
      }

      // Handle Total Site Visits
      let currentVisits = 0;
      if (storedVisits) {
        currentVisits = parseInt(storedVisits, 10);
      }
      const newVisits = (isNaN(currentVisits) ? 0 : currentVisits) + 1;
      setSiteVisits(newVisits);
      localStorage.setItem('forum_site_visits', newVisits.toString());

      // Handle Daily Visits
      const today = format(new Date(), 'yyyy-MM-dd');
      let currentDailyVisits = 0;
      
      if (storedLastVisitDate === today && storedDailyVisits) {
        currentDailyVisits = parseInt(storedDailyVisits, 10);
      } else {
        currentDailyVisits = 0; 
      }
      
      const newDailyVisits = (isNaN(currentDailyVisits) ? 0 : currentDailyVisits) + 1;
      setDailyVisits(newDailyVisits);
      localStorage.setItem('forum_daily_visits', newDailyVisits.toString());
      localStorage.setItem('forum_last_visit_date', today);
    };
    loadData();
    
    const interval = setInterval(checkAutoApprove, 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const checkAutoApprove = () => {
    if (moderationRules.autoApproveTimeout <= 0) return;
    
    let updatedThreads = false;
    let updatedPosts = false;
    
    const now = new Date();
    
    const newThreads = threads.map(t => {
      if (t.status === 'pending') {
        const hoursDiff = differenceInHours(now, new Date(t.createdAt));
        if (hoursDiff >= moderationRules.autoApproveTimeout) {
          updatedThreads = true;
          return { ...t, status: 'approved' as const };
        }
      }
      return t;
    });
    
    if (updatedThreads) saveThreads(newThreads);
    
    const newPosts = posts.map(p => {
       if (p.status === 'pending') {
         const hoursDiff = differenceInHours(now, new Date(p.createdAt));
         if (hoursDiff >= moderationRules.autoApproveTimeout) {
           updatedPosts = true;
           return { ...p, status: 'approved' as const };
         }
       }
       return p;
    });
    
    if (updatedPosts) savePosts(newPosts);
  };

  const saveCategories = (newCats: Category[]) => {
    setCategories(newCats);
    localStorage.setItem('forum_categories', encryptData(newCats));
  };

  const saveThreads = (newThreads: Thread[]) => {
    setThreads(newThreads);
    localStorage.setItem('forum_threads', encryptData(newThreads));
  };

  const savePosts = (newPosts: Post[]) => {
    setPosts(newPosts);
    localStorage.setItem('forum_posts', encryptData(newPosts));
  };
  
  const saveNotifications = (newNotifs: Notification[]) => {
    setNotifications(newNotifs);
    localStorage.setItem('forum_notifications', encryptData(newNotifs));
  };

  const saveMessages = (newMsgs: Message[]) => {
    setMessages(newMsgs);
    localStorage.setItem('forum_messages', encryptData(newMsgs));
  };
  
  const saveBannedKeywords = (newKeywords: string[]) => {
    setBannedKeywords(newKeywords);
    localStorage.setItem('forum_banned_keywords', encryptData(newKeywords));
  };
  
  const saveFollowActivities = (activities: FollowActivity[]) => {
    setFollowActivities(activities);
    localStorage.setItem('forum_follow_activities', encryptData(activities));
  };
  
  const updateModerationRules = (newRules: AutoModerationRules) => {
    setModerationRules(newRules);
    localStorage.setItem('forum_moderation_rules', encryptData(newRules));
  };

  const addCategory = (name: string, description: string, icon: string, color: string) => {
    const newCategory: Category = {
      id: `cat_${uuidv4()}`,
      name,
      description,
      icon,
      color
    };
    saveCategories([...categories, newCategory]);
  };

  const deleteCategory = (categoryId: string) => {
    saveCategories(categories.filter(c => c.id !== categoryId));
    
    const threadsToDelete = threads.filter(t => t.categoryId === categoryId);
    const threadIdsToDelete = threadsToDelete.map(t => t.id);
    
    const remainingThreads = threads.filter(t => t.categoryId !== categoryId);
    saveThreads(remainingThreads);

    const remainingPosts = posts.filter(p => !threadIdsToDelete.includes(p.threadId));
    savePosts(remainingPosts);
  };

  const checkForBannedContent = (text: string): boolean => {
    if (text.match(/https?:\/\/[^\s]+/) || text.match(/www\.[^\s]+/)) {
      return true;
    }
    return bannedKeywords.some(keyword => text.toLowerCase().includes(keyword.toLowerCase()));
  };

  const hasMedia = (blocks: ContentBlock[]): boolean => {
    return blocks.some(b => b.type === 'image' || b.type === 'video');
  };

  const createThread = (
    categoryId: string, 
    title: string, 
    blocks: ContentBlock[], 
    user: any,
    options: CreateThreadOptions = { hideType: 'none' }
  ) => {
    const contentString = blocks.map(b => b.value).join(' ');
    let isFlagged = checkForBannedContent(title) || checkForBannedContent(contentString);
    
    if (!isFlagged && moderationRules.requireMediaReview && hasMedia(blocks)) {
      isFlagged = true;
    }
    
    const newThread: Thread = {
      id: uuidv4(),
      categoryId,
      authorId: user.id,
      authorName: user.nickname || user.username,
      title,
      blocks,
      coverImage: options.coverImage,
      isHidden: false,
      status: isFlagged ? 'pending' : 'approved',
      hideType: options.hideType,
      price: options.price,
      hiddenContent: options.hiddenContent,
      rewardConfig: options.rewardConfig,
      views: 0,
      replies: 0,
      isPinned: false,
      isFeatured: false,
      likes: [],
      shares: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastReplyAt: new Date().toISOString()
    };

    saveThreads([newThread, ...threads]);
    
    // Create follow activity for followers
    if (!isFlagged) {
      const activity: FollowActivity = {
        id: uuidv4(),
        userId: user.id,
        type: 'new_thread',
        threadId: newThread.id,
        threadTitle: title,
        createdAt: new Date().toISOString()
      };
      saveFollowActivities([activity, ...followActivities]);
    }
  };

  const createPost = (threadId: string, content: string, user: any, parentId?: string) => {
    let blocks: ContentBlock[] = [];
    try {
      blocks = JSON.parse(content);
    } catch (e) {
      blocks = [{ id: '1', type: 'text', value: content }];
    }
    
    const contentString = blocks.map(b => b.value).join(' ');
    let isFlagged = checkForBannedContent(contentString);

    if (!isFlagged && moderationRules.requireMediaReview && hasMedia(blocks)) {
      isFlagged = true;
    }
    
    const newPost: Post = {
      id: uuidv4(),
      threadId,
      authorId: user.id,
      authorName: user.nickname || user.username,
      authorAvatar: user.avatar,
      content,
      status: isFlagged ? 'pending' : 'approved',
      parentId,
      createdAt: new Date().toISOString()
    };

    savePosts([...posts, newPost]);

    if (!isFlagged) {
      let rewardWon = false;
      let rewardAmount = 0;
      
      const updatedThreads = threads.map(t => {
        if (t.id === threadId) {
          const updated = {
            ...t,
            replies: t.replies + 1,
            updatedAt: new Date().toISOString(),
            lastReplyAt: new Date().toISOString()
          };
          
          if (t.rewardConfig && t.rewardConfig.enabled && t.rewardConfig.remainingBudget > 0) {
            const winnersIds = t.rewardConfig.winnersIds || [];
            
            if (!winnersIds.includes(user.id) && t.authorId !== user.id) {
              const roll = Math.random() * 100;
              
              if (roll <= t.rewardConfig.probability) {
                rewardAmount = Math.min(t.rewardConfig.amountPerReward, t.rewardConfig.remainingBudget);
                
                if (rewardAmount > 0) {
                  rewardWon = true;
                  updated.rewardConfig = {
                    ...t.rewardConfig,
                    remainingBudget: t.rewardConfig.remainingBudget - rewardAmount,
                    winnersIds: [...winnersIds, user.id]
                  };
                }
              }
            }
          }
          
          return updated;
        }
        return t;
      });
      saveThreads(updatedThreads);
      
      if (rewardWon && rewardAmount > 0) {
        const rewardNotif: Notification = {
          id: uuidv4(),
          userId: user.id,
          type: 'system',
          message: `🎉 恭喜！您在回帖抽奖中获得了 ${rewardAmount} 积分！`,
          isRead: false,
          createdAt: new Date().toISOString()
        };
        saveNotifications([...notifications, rewardNotif]);
      }

      if (parentId) {
        const parentPost = posts.find(p => p.id === parentId);
        if (parentPost && parentPost.authorId !== user.id) {
          const newNotif: Notification = {
            id: uuidv4(),
            userId: parentPost.authorId,
            type: 'reply',
            message: `${user.nickname || user.username} 回复了您的评论`,
            link: `/thread/${threadId}`,
            isRead: false,
            createdAt: new Date().toISOString()
          };
          saveNotifications([...notifications, newNotif]);
        }
      } else {
         const thread = threads.find(t => t.id === threadId);
         if (thread && thread.authorId !== user.id) {
           const newNotif: Notification = {
            id: uuidv4(),
            userId: thread.authorId,
            type: 'reply',
            message: `${user.nickname || user.username} 回复了您的帖子: ${thread.title}`,
            link: `/thread/${threadId}`,
            isRead: false,
            createdAt: new Date().toISOString()
          };
          saveNotifications([...notifications, newNotif]);
         }
      }
    }
  };

  const likeThread = (threadId: string, userId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        const likes = t.likes || [];
        if (likes.includes(userId)) {
          // Unlike
          return { ...t, likes: likes.filter(id => id !== userId) };
        } else {
          // Like
          return { ...t, likes: [...likes, userId] };
        }
      }
      return t;
    });
    saveThreads(updatedThreads);
  };

  const shareThread = (threadId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        return { ...t, shares: (t.shares || 0) + 1 };
      }
      return t;
    });
    saveThreads(updatedThreads);
    
    // Copy link to clipboard
    const url = `${window.location.origin}/thread/${threadId}`;
    navigator.clipboard.writeText(url);
  };

  const likePost = (postId: string, userId: string) => {
    const updatedPosts = posts.map(p => {
      if (p.id === postId) {
        const likes = p.likes || [];
        if (likes.includes(userId)) {
          // Unlike
          return { ...p, likes: likes.filter(id => id !== userId) };
        } else {
          // Like
          return { ...p, likes: [...likes, userId] };
        }
      }
      return p;
    });
    savePosts(updatedPosts);
  };

  const tipThread = (threadId: string, userId: string, userName: string, amount: number): boolean => {
    const thread = threads.find(t => t.id === threadId);
    if (!thread) return false;
    
    const tip = {
      userId,
      userName,
      amount,
      createdAt: new Date().toISOString()
    };
    
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        return {
          ...t,
          tips: [...(t.tips || []), tip]
        };
      }
      return t;
    });
    saveThreads(updatedThreads);
    
    // Send notification to author
    const newNotif: Notification = {
      id: uuidv4(),
      userId: thread.authorId,
      type: 'system',
      message: `${userName} 打赏了您的帖子 ${amount} 积分`,
      link: `/thread/${threadId}`,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    saveNotifications([...notifications, newNotif]);
    
    return true;
  };

  const tipPost = (postId: string, userId: string, userName: string, amount: number): boolean => {
    const post = posts.find(p => p.id === postId);
    if (!post) return false;
    
    const tip = {
      userId,
      userName,
      amount,
      createdAt: new Date().toISOString()
    };
    
    const updatedPosts = posts.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          tips: [...(p.tips || []), tip]
        };
      }
      return p;
    });
    savePosts(updatedPosts);
    
    // Send notification to author
    const newNotif: Notification = {
      id: uuidv4(),
      userId: post.authorId,
      type: 'system',
      message: `${userName} 打赏了您的评论 ${amount} 积分`,
      link: `/thread/${post.threadId}`,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    saveNotifications([...notifications, newNotif]);
    
    return true;
  };

  const deleteThread = (threadId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        return { ...t, deletedAt: new Date().toISOString() };
      }
      return t;
    });
    saveThreads(updatedThreads);
  };

  const restoreThread = (threadId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        const { deletedAt, ...rest } = t;
        return rest as Thread;
      }
      return t;
    });
    saveThreads(updatedThreads);
  };

  const permanentlyDeleteThread = (threadId: string) => {
    saveThreads(threads.filter(t => t.id !== threadId));
    savePosts(posts.filter(p => p.threadId !== threadId));
  };

  const toggleThreadVisibility = (threadId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        return { ...t, isHidden: !t.isHidden };
      }
      return t;
    });
    saveThreads(updatedThreads);
  };

  const togglePinThread = (threadId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        return { ...t, isPinned: !t.isPinned };
      }
      return t;
    });
    saveThreads(updatedThreads);
  };

  const toggleFeatureThread = (threadId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        return { ...t, isFeatured: !t.isFeatured };
      }
      return t;
    });
    saveThreads(updatedThreads);
  };
  
  const approveThread = (threadId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) return { ...t, status: 'approved' as const };
      return t;
    });
    saveThreads(updatedThreads);
  };

  const rejectThread = (threadId: string) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) return { ...t, status: 'rejected' as const };
      return t;
    });
    saveThreads(updatedThreads);
  };
  
  const sendMessage = (senderId: string, senderName: string, receiverId: string, content: string) => {
    const newMsg: Message = {
      id: uuidv4(),
      senderId,
      senderName,
      receiverId,
      content,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    saveMessages([...messages, newMsg]);
  };
  
  const markNotificationRead = (notifId: string) => {
    const updated = notifications.map(n => n.id === notifId ? { ...n, isRead: true } : n);
    saveNotifications(updated);
  };

  const updateThread = (threadId: string, title: string, blocks: ContentBlock[], options: CreateThreadOptions = { hideType: 'none' }) => {
    const updatedThreads = threads.map(t => {
      if (t.id === threadId) {
        return {
          ...t,
          title,
          blocks,
          coverImage: options.coverImage,
          hideType: options.hideType,
          price: options.price,
          hiddenContent: options.hiddenContent,
          rewardConfig: options.rewardConfig,
          updatedAt: new Date().toISOString()
        };
      }
      return t;
    });
    saveThreads(updatedThreads);
  };
  
  const addBannedKeyword = (keyword: string) => {
    if (!bannedKeywords.includes(keyword)) {
      saveBannedKeywords([...bannedKeywords, keyword]);
    }
  };

  const removeBannedKeyword = (keyword: string) => {
    saveBannedKeywords(bannedKeywords.filter(k => k !== keyword));
  };

  const getThreadsByCategory = (categoryId: string) => {
    return threads
      .filter(t => t.categoryId === categoryId)
      .sort((a, b) => new Date(b.lastReplyAt).getTime() - new Date(a.lastReplyAt).getTime());
  };

  const getPostsByThread = (threadId: string) => {
    return posts
      .filter(p => p.threadId === threadId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  };

  const getThread = (threadId: string) => threads.find(t => t.id === threadId);

  return (
    <ForumContext.Provider value={{ 
      categories, 
      threads, 
      posts, 
      siteVisits,
      dailyVisits,
      notifications,
      messages,
      bannedKeywords,
      moderationRules,
      followActivities,
      createThread, 
      createPost, 
      addCategory, 
      deleteCategory,
      deleteThread,
      restoreThread,
      permanentlyDeleteThread,
      updateThread,
      toggleThreadVisibility,
      togglePinThread,
      toggleFeatureThread,
      likeThread,
      shareThread,
      likePost,
      tipThread,
      tipPost,
      approveThread,
      rejectThread,
      addBannedKeyword,
      removeBannedKeyword,
      updateModerationRules,
      sendMessage,
      markNotificationRead,
      getThreadsByCategory, 
      getPostsByThread,
      getThread
    }}>
      {children}
    </ForumContext.Provider>
  );
};

export const useForum = () => {
  const context = useContext(ForumContext);
  if (context === undefined) {
    throw new Error('useForum must be used within a ForumProvider');
  }
  return context;
};
