import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ForumProvider } from './context/ForumContext';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { CategoryView } from './pages/CategoryView';
import { CreateThread } from './pages/CreateThread';
import { ThreadView } from './pages/ThreadView';
import { Profile } from './pages/Profile';
import { AdminDashboard } from './pages/AdminDashboard';
import { Notifications } from './pages/Notifications';
import { Messages } from './pages/Messages';
import { Sponsor } from './pages/Sponsor';
import { Guide } from './pages/Guide';
import { Favorites } from './pages/Favorites';
import { DataManagement } from './pages/DataManagement';

export function App() {
  return (
    <Router>
      <AuthProvider>
        <ForumProvider>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="login" element={<Login />} />
              <Route path="register" element={<Register />} />
              <Route path="profile" element={<Profile />} />
              <Route path="profile/:userId" element={<Profile />} />
              <Route path="notifications" element={<Notifications />} />
              <Route path="messages" element={<Messages />} />
              <Route path="sponsor" element={<Sponsor />} />
              <Route path="guide" element={<Guide />} />
              <Route path="favorites" element={<Favorites />} />
              <Route path="data-management" element={<DataManagement />} />
              <Route path="category/:categoryId" element={<CategoryView />} />
              <Route path="create-thread/:categoryId" element={<CreateThread />} />
              <Route path="thread/:threadId" element={<ThreadView />} />
              <Route path="admin" element={<AdminDashboard />} />
              <Route path="edit/:threadId" element={<CreateThread />} />
            </Route>
          </Routes>
        </ForumProvider>
      </AuthProvider>
    </Router>
  );
}
