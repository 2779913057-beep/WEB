const express = require('express');
const cors = require('cors');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3001;

// Encryption settings
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'sudocg-secret-key-2024-secure!!';
const ALGORITHM = 'aes-256-cbc';

// Ensure key is 32 bytes
const getKey = () => {
  return crypto.createHash('sha256').update(ENCRYPTION_KEY).digest();
};

// Encrypt data
const encrypt = (data) => {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGORITHM, getKey(), iv);
  let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return iv.toString('hex') + ':' + encrypted;
};

// Decrypt data
const decrypt = (encryptedData) => {
  try {
    const parts = encryptedData.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const encryptedText = parts[1];
    const decipher = crypto.createDecipheriv(ALGORITHM, getKey(), iv);
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
  } catch (error) {
    console.error('Decryption error:', error);
    return null;
  }
};

// Data directory
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Read encrypted data file
const readDataFile = (filename) => {
  const filePath = path.join(DATA_DIR, filename);
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const encryptedData = fs.readFileSync(filePath, 'utf8');
  return decrypt(encryptedData);
};

// Write encrypted data file
const writeDataFile = (filename, data) => {
  const filePath = path.join(DATA_DIR, filename);
  const encryptedData = encrypt(data);
  fs.writeFileSync(filePath, encryptedData, 'utf8');
};

// Initialize default data
const initializeData = () => {
  // Users
  if (!readDataFile('users.enc')) {
    const defaultUsers = [{
      id: 'admin-001',
      username: 'admin',
      password: crypto.createHash('sha256').update('admin123').digest('hex'),
      nickname: '管理员',
      role: 'admin',
      points: 9999,
      avatar: '',
      gender: 'other',
      phone: '',
      email: 'admin@sudocg.com',
      securityQuestion: '网站名称是什么？',
      securityAnswer: 'sudocg',
      follows: [],
      followers: [],
      purchasedThreads: [],
      isBanned: false,
      createdAt: new Date().toISOString(),
      lastLoginDate: ''
    }];
    writeDataFile('users.enc', defaultUsers);
    console.log('初始化默认管理员账号: admin / admin123');
  }

  // Categories
  if (!readDataFile('categories.enc')) {
    const defaultCategories = [
      { id: 'cat-1', name: '2D美术资源', description: '原画、插画、UI素材分享', createdAt: new Date().toISOString() },
      { id: 'cat-2', name: '3D模型资源', description: '角色、场景、道具模型', createdAt: new Date().toISOString() },
      { id: 'cat-3', name: '教程分享', description: '绘画技巧与软件教程', createdAt: new Date().toISOString() },
      { id: 'cat-4', name: '作品展示', description: '展示你的原创作品', createdAt: new Date().toISOString() }
    ];
    writeDataFile('categories.enc', defaultCategories);
  }

  // Threads
  if (!readDataFile('threads.enc')) {
    writeDataFile('threads.enc', []);
  }

  // Posts
  if (!readDataFile('posts.enc')) {
    writeDataFile('posts.enc', []);
  }

  // Notifications
  if (!readDataFile('notifications.enc')) {
    writeDataFile('notifications.enc', []);
  }

  // Messages
  if (!readDataFile('messages.enc')) {
    writeDataFile('messages.enc', []);
  }

  // Redemption codes
  if (!readDataFile('codes.enc')) {
    writeDataFile('codes.enc', []);
  }

  // Site stats
  if (!readDataFile('stats.enc')) {
    writeDataFile('stats.enc', { 
      totalVisits: 0, 
      dailyVisits: 0, 
      lastVisitDate: new Date().toISOString().split('T')[0] 
    });
  }

  // Moderation rules
  if (!readDataFile('moderation.enc')) {
    writeDataFile('moderation.enc', {
      bannedKeywords: [],
      autoApproveKeywords: [],
      requireMediaReview: true,
      autoApproveTimeout: 24
    });
  }
};

initializeData();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Serve static files in production
app.use(express.static(path.join(__dirname, '../dist')));

// ============ API Routes ============

// --- Auth ---
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const users = readDataFile('users.enc') || [];
  const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
  
  const user = users.find(u => u.username === username && u.password === hashedPassword);
  
  if (!user) {
    return res.status(401).json({ error: '账号或密码错误' });
  }
  
  if (user.isBanned) {
    return res.status(403).json({ error: '该账号已被封禁' });
  }
  
  // Update last login date and give daily points
  const today = new Date().toISOString().split('T')[0];
  let pointsAwarded = 0;
  if (user.lastLoginDate !== today) {
    user.points = (user.points || 0) + 10;
    user.lastLoginDate = today;
    pointsAwarded = 10;
    
    const updatedUsers = users.map(u => u.id === user.id ? user : u);
    writeDataFile('users.enc', updatedUsers);
  }
  
  // Return user without password
  const { password: _, ...safeUser } = user;
  res.json({ user: safeUser, pointsAwarded });
});

app.post('/api/auth/register', (req, res) => {
  const { username, password, nickname, gender, phone, email, securityQuestion, securityAnswer } = req.body;
  
  // Validate username (only alphanumeric)
  if (!/^[a-zA-Z0-9]+$/.test(username)) {
    return res.status(400).json({ error: '用户名只能包含英文和数字' });
  }
  
  const users = readDataFile('users.enc') || [];
  
  if (users.some(u => u.username === username)) {
    return res.status(400).json({ error: '用户名已存在' });
  }
  
  const newUser = {
    id: `user-${Date.now()}`,
    username,
    password: crypto.createHash('sha256').update(password).digest('hex'),
    nickname: nickname || username,
    role: 'member',
    points: 100,
    avatar: '',
    gender: gender || 'other',
    phone: phone || '',
    email: email || '',
    securityQuestion: securityQuestion || '',
    securityAnswer: securityAnswer || '',
    follows: [],
    followers: [],
    purchasedThreads: [],
    isBanned: false,
    createdAt: new Date().toISOString(),
    lastLoginDate: ''
  };
  
  users.push(newUser);
  writeDataFile('users.enc', users);
  
  const { password: _, ...safeUser } = newUser;
  res.json({ user: safeUser });
});

// --- Users ---
app.get('/api/users', (req, res) => {
  const users = readDataFile('users.enc') || [];
  const safeUsers = users.map(({ password, ...u }) => u);
  res.json(safeUsers);
});

app.get('/api/users/:id', (req, res) => {
  const users = readDataFile('users.enc') || [];
  const user = users.find(u => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ error: '用户不存在' });
  }
  const { password, ...safeUser } = user;
  res.json(safeUser);
});

app.put('/api/users/:id', (req, res) => {
  const users = readDataFile('users.enc') || [];
  const index = users.findIndex(u => u.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: '用户不存在' });
  }
  
  const updates = req.body;
  
  // Hash password if being updated
  if (updates.password) {
    updates.password = crypto.createHash('sha256').update(updates.password).digest('hex');
  }
  
  users[index] = { ...users[index], ...updates };
  writeDataFile('users.enc', users);
  
  const { password, ...safeUser } = users[index];
  res.json(safeUser);
});

app.delete('/api/users/:id', (req, res) => {
  const users = readDataFile('users.enc') || [];
  const filtered = users.filter(u => u.id !== req.params.id);
  writeDataFile('users.enc', filtered);
  res.json({ success: true });
});

// --- Categories ---
app.get('/api/categories', (req, res) => {
  const categories = readDataFile('categories.enc') || [];
  res.json(categories);
});

app.post('/api/categories', (req, res) => {
  const categories = readDataFile('categories.enc') || [];
  const newCategory = {
    id: `cat-${Date.now()}`,
    ...req.body,
    createdAt: new Date().toISOString()
  };
  categories.push(newCategory);
  writeDataFile('categories.enc', categories);
  res.json(newCategory);
});

app.delete('/api/categories/:id', (req, res) => {
  let categories = readDataFile('categories.enc') || [];
  let threads = readDataFile('threads.enc') || [];
  let posts = readDataFile('posts.enc') || [];
  
  // Get thread IDs in this category
  const threadIds = threads.filter(t => t.categoryId === req.params.id).map(t => t.id);
  
  // Delete posts in those threads
  posts = posts.filter(p => !threadIds.includes(p.threadId));
  
  // Delete threads
  threads = threads.filter(t => t.categoryId !== req.params.id);
  
  // Delete category
  categories = categories.filter(c => c.id !== req.params.id);
  
  writeDataFile('categories.enc', categories);
  writeDataFile('threads.enc', threads);
  writeDataFile('posts.enc', posts);
  
  res.json({ success: true });
});

// --- Threads ---
app.get('/api/threads', (req, res) => {
  const threads = readDataFile('threads.enc') || [];
  res.json(threads);
});

app.get('/api/threads/:id', (req, res) => {
  const threads = readDataFile('threads.enc') || [];
  const thread = threads.find(t => t.id === req.params.id);
  if (!thread) {
    return res.status(404).json({ error: '帖子不存在' });
  }
  
  // Increment view count
  thread.views = (thread.views || 0) + 1;
  writeDataFile('threads.enc', threads);
  
  res.json(thread);
});

app.post('/api/threads', (req, res) => {
  const threads = readDataFile('threads.enc') || [];
  const modRules = readDataFile('moderation.enc') || {};
  const users = readDataFile('users.enc') || [];
  
  const { blocks, authorId } = req.body;
  
  // Determine status based on moderation rules
  let status = 'approved';
  
  // Check for media (images/videos)
  const hasMedia = blocks && blocks.some(b => b.type === 'image' || b.type === 'video');
  if (hasMedia && modRules.requireMediaReview) {
    status = 'pending';
  }
  
  // Check for links
  const contentText = blocks ? blocks.map(b => b.content || '').join(' ') : '';
  if (/https?:\/\//i.test(contentText)) {
    status = 'pending';
  }
  
  // Check banned keywords
  if (modRules.bannedKeywords && modRules.bannedKeywords.length > 0) {
    const lowerContent = contentText.toLowerCase();
    if (modRules.bannedKeywords.some(kw => lowerContent.includes(kw.toLowerCase()))) {
      status = 'rejected';
    }
  }
  
  const newThread = {
    id: `thread-${Date.now()}`,
    ...req.body,
    status,
    views: 0,
    replies: 0,
    isPinned: false,
    isFeatured: false,
    isHidden: false,
    createdAt: new Date().toISOString()
  };
  
  threads.push(newThread);
  writeDataFile('threads.enc', threads);
  
  // Award points to author
  if (status === 'approved') {
    const userIndex = users.findIndex(u => u.id === authorId);
    if (userIndex !== -1) {
      users[userIndex].points = (users[userIndex].points || 0) + 10;
      writeDataFile('users.enc', users);
    }
  }
  
  res.json(newThread);
});

app.put('/api/threads/:id', (req, res) => {
  const threads = readDataFile('threads.enc') || [];
  const index = threads.findIndex(t => t.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: '帖子不存在' });
  }
  
  threads[index] = { ...threads[index], ...req.body };
  writeDataFile('threads.enc', threads);
  res.json(threads[index]);
});

app.delete('/api/threads/:id', (req, res) => {
  let threads = readDataFile('threads.enc') || [];
  let posts = readDataFile('posts.enc') || [];
  
  threads = threads.filter(t => t.id !== req.params.id);
  posts = posts.filter(p => p.threadId !== req.params.id);
  
  writeDataFile('threads.enc', threads);
  writeDataFile('posts.enc', posts);
  
  res.json({ success: true });
});

// --- Posts ---
app.get('/api/posts', (req, res) => {
  const posts = readDataFile('posts.enc') || [];
  const { threadId } = req.query;
  if (threadId) {
    return res.json(posts.filter(p => p.threadId === threadId));
  }
  res.json(posts);
});

app.post('/api/posts', (req, res) => {
  const posts = readDataFile('posts.enc') || [];
  const threads = readDataFile('threads.enc') || [];
  const users = readDataFile('users.enc') || [];
  const notifications = readDataFile('notifications.enc') || [];
  const modRules = readDataFile('moderation.enc') || {};
  
  const { blocks, authorId, threadId, parentId } = req.body;
  
  // Determine status
  let status = 'approved';
  const hasMedia = blocks && blocks.some(b => b.type === 'image' || b.type === 'video');
  if (hasMedia && modRules.requireMediaReview) {
    status = 'pending';
  }
  
  const contentText = blocks ? blocks.map(b => b.content || '').join(' ') : '';
  if (/https?:\/\//i.test(contentText)) {
    status = 'pending';
  }
  
  if (modRules.bannedKeywords && modRules.bannedKeywords.length > 0) {
    const lowerContent = contentText.toLowerCase();
    if (modRules.bannedKeywords.some(kw => lowerContent.includes(kw.toLowerCase()))) {
      status = 'rejected';
    }
  }
  
  const newPost = {
    id: `post-${Date.now()}`,
    ...req.body,
    status,
    createdAt: new Date().toISOString()
  };
  
  posts.push(newPost);
  
  // Update thread reply count
  const threadIndex = threads.findIndex(t => t.id === threadId);
  if (threadIndex !== -1) {
    threads[threadIndex].replies = (threads[threadIndex].replies || 0) + 1;
    writeDataFile('threads.enc', threads);
    
    // Create notification for thread author
    if (status === 'approved' && threads[threadIndex].authorId !== authorId) {
      notifications.push({
        id: `notif-${Date.now()}`,
        userId: threads[threadIndex].authorId,
        type: 'reply',
        message: `有人回复了您的帖子《${threads[threadIndex].title}》`,
        threadId,
        read: false,
        createdAt: new Date().toISOString()
      });
    }
  }
  
  // If replying to a post, notify that post's author
  if (parentId) {
    const parentPost = posts.find(p => p.id === parentId);
    if (parentPost && parentPost.authorId !== authorId) {
      notifications.push({
        id: `notif-${Date.now()}-reply`,
        userId: parentPost.authorId,
        type: 'reply',
        message: `有人回复了您的评论`,
        threadId,
        read: false,
        createdAt: new Date().toISOString()
      });
    }
  }
  
  writeDataFile('posts.enc', posts);
  writeDataFile('notifications.enc', notifications);
  
  // Award points
  if (status === 'approved') {
    const userIndex = users.findIndex(u => u.id === authorId);
    if (userIndex !== -1) {
      users[userIndex].points = (users[userIndex].points || 0) + 2;
      writeDataFile('users.enc', users);
    }
  }
  
  res.json(newPost);
});

// --- Notifications ---
app.get('/api/notifications/:userId', (req, res) => {
  const notifications = readDataFile('notifications.enc') || [];
  const userNotifications = notifications.filter(n => n.userId === req.params.userId);
  res.json(userNotifications);
});

app.put('/api/notifications/:id/read', (req, res) => {
  const notifications = readDataFile('notifications.enc') || [];
  const index = notifications.findIndex(n => n.id === req.params.id);
  if (index !== -1) {
    notifications[index].read = true;
    writeDataFile('notifications.enc', notifications);
  }
  res.json({ success: true });
});

// --- Messages ---
app.get('/api/messages/:userId', (req, res) => {
  const messages = readDataFile('messages.enc') || [];
  const userMessages = messages.filter(m => 
    m.senderId === req.params.userId || m.receiverId === req.params.userId
  );
  res.json(userMessages);
});

app.post('/api/messages', (req, res) => {
  const messages = readDataFile('messages.enc') || [];
  const newMessage = {
    id: `msg-${Date.now()}`,
    ...req.body,
    read: false,
    createdAt: new Date().toISOString()
  };
  messages.push(newMessage);
  writeDataFile('messages.enc', messages);
  res.json(newMessage);
});

// --- Redemption Codes ---
app.get('/api/codes', (req, res) => {
  const codes = readDataFile('codes.enc') || [];
  res.json(codes);
});

app.post('/api/codes', (req, res) => {
  const codes = readDataFile('codes.enc') || [];
  const newCode = {
    id: `code-${Date.now()}`,
    code: `SUDO${Date.now().toString(36).toUpperCase()}`,
    points: req.body.points || 100,
    used: false,
    createdAt: new Date().toISOString()
  };
  codes.push(newCode);
  writeDataFile('codes.enc', codes);
  res.json(newCode);
});

app.post('/api/codes/redeem', (req, res) => {
  const { code, userId } = req.body;
  const codes = readDataFile('codes.enc') || [];
  const users = readDataFile('users.enc') || [];
  
  const codeIndex = codes.findIndex(c => c.code === code && !c.used);
  if (codeIndex === -1) {
    return res.status(400).json({ error: '无效或已使用的兑换码' });
  }
  
  const userIndex = users.findIndex(u => u.id === userId);
  if (userIndex === -1) {
    return res.status(404).json({ error: '用户不存在' });
  }
  
  // Apply points
  users[userIndex].points = (users[userIndex].points || 0) + codes[codeIndex].points;
  codes[codeIndex].used = true;
  codes[codeIndex].usedBy = userId;
  codes[codeIndex].usedAt = new Date().toISOString();
  
  writeDataFile('codes.enc', codes);
  writeDataFile('users.enc', users);
  
  res.json({ points: codes[codeIndex].points });
});

// --- Site Stats ---
app.get('/api/stats', (req, res) => {
  const stats = readDataFile('stats.enc') || { totalVisits: 0, dailyVisits: 0 };
  res.json(stats);
});

app.post('/api/stats/visit', (req, res) => {
  const stats = readDataFile('stats.enc') || { totalVisits: 0, dailyVisits: 0, lastVisitDate: '' };
  const today = new Date().toISOString().split('T')[0];
  
  if (stats.lastVisitDate !== today) {
    stats.dailyVisits = 1;
    stats.lastVisitDate = today;
  } else {
    stats.dailyVisits++;
  }
  stats.totalVisits++;
  
  writeDataFile('stats.enc', stats);
  res.json(stats);
});

// --- Moderation ---
app.get('/api/moderation', (req, res) => {
  const rules = readDataFile('moderation.enc') || {};
  res.json(rules);
});

app.put('/api/moderation', (req, res) => {
  const rules = readDataFile('moderation.enc') || {};
  const updated = { ...rules, ...req.body };
  writeDataFile('moderation.enc', updated);
  res.json(updated);
});

// Fallback to index.html for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

app.listen(PORT, () => {
  console.log(`SudoCG 服务器运行在 http://localhost:${PORT}`);
  console.log(`默认管理员账号: admin / admin123`);
});
