import CryptoJS from 'crypto-js';

// In a real app, this key would be securely managed on the server or derived.
// For this frontend demo, we use a constant key to simulate "encrypted storage" on the client (localStorage).
const APP_SECRET_KEY = 'my-super-secret-forum-key-2024';

export const encryptData = (data: any): string => {
  try {
    const jsonString = JSON.stringify(data);
    return CryptoJS.AES.encrypt(jsonString, APP_SECRET_KEY).toString();
  } catch (error) {
    console.error("Encryption failed:", error);
    return "";
  }
};

export const decryptData = <T>(ciphertext: string): T | null => {
  try {
    if (!ciphertext) return null;
    const bytes = CryptoJS.AES.decrypt(ciphertext, APP_SECRET_KEY);
    const decryptedData = bytes.toString(CryptoJS.enc.Utf8);
    if (!decryptedData) return null;
    return JSON.parse(decryptedData) as T;
  } catch (error) {
    console.error("Decryption failed:", error);
    return null;
  }
};
