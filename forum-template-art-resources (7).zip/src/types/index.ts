export interface User {
  id: string;
  username: string; // Used for login
  password?: string; // Store password (in real app, hash it)
  nickname?: string;
  gender?: 'male' | 'female' | 'other';
  phone?: string;
  email?: string;
  avatar: string;
  role: 'admin' | 'user';
  points: number;
  purchasedThreads: string[];
  createdAt: string;
  isBanned?: boolean;
  
  // Social
  follows?: string[]; // IDs of users this user follows
  followers?: string[]; // IDs of users following this user
  
  // Favorites
  favorites?: string[]; // Thread IDs user has favorited

  // Security
  securityQuestion?: string;
  securityAnswer?: string;
  passwordChangeCount?: number;
  lastPasswordChangeDate?: string; // YYYY-MM-DD
  lastLoginDate?: string; // YYYY-MM-DD
  
  // Invitation system
  inviteCode?: string; // User's unique invite code
  invitedBy?: string; // ID of user who invited this user
  inviteCount?: number; // Number of users this user has invited
  
  // Session
  loginToken?: string;
  loginExpiry?: string; // ISO date when 7-day session expires
}

export interface Notification {
  id: string;
  userId: string; // The user receiving the notification
  type: 'reply' | 'follow' | 'system';
  message: string;
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string; // nickname or username
  receiverId: string;
  content: string;
  isRead: boolean;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
}

export type BlockType = 'header' | 'text' | 'image' | 'video';

export interface ContentBlock {
  id: string;
  type: BlockType;
  value: string;
}

export interface RewardConfig {
  enabled: boolean;
  totalBudget: number;
  remainingBudget: number;
  amountPerReward: number;
  probability: number; // 10-100
  winnersIds?: string[]; // Track who already won
}

export interface Thread {
  id: string;
  categoryId: string;
  authorId: string;
  authorName: string;
  title: string;
  blocks: ContentBlock[]; 
  
  // Cover image
  coverImage?: string;
  
  // Admin flags
  isHidden: boolean;
  status?: 'approved' | 'pending' | 'rejected';
  deletedAt?: string; // Soft delete timestamp
  
  // User content hiding features
  hideType: 'none' | 'reply' | 'pay';
  price?: number;
  hiddenContent?: string;
  
  // Reply reward system
  rewardConfig?: RewardConfig;

  views: number;
  replies: number;
  isPinned: boolean;
  isFeatured: boolean;
  createdAt: string;
  updatedAt: string;
  lastReplyAt: string;
  
  // Social features
  likes: string[]; // User IDs who liked
  shares: number; // Share count
}

export interface FollowActivity {
  id: string;
  userId: string; // The user who did something
  type: 'new_thread';
  threadId: string;
  threadTitle: string;
  createdAt: string;
}

export interface Post {
  id: string;
  threadId: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  content: string; // HTML content or JSON block string
  status?: 'approved' | 'pending' | 'rejected';
  parentId?: string; // For nested replies
  createdAt: string;
}

export interface EncryptedData {
  data: string;
}

export interface RedemptionCode {
  id: string;
  code: string;
  points: number;
  isUsed: boolean;
  generatedBy: string; // admin username
  createdAt: string;
}

export interface AutoModerationRules {
  requireMediaReview: boolean; // If true, posts with image/video blocks are pending
  autoApproveTimeout: number; // Hours after which pending posts are auto-approved (0 = disabled)
  // bannedKeywords is handled separately in context, but conceptually part of rules
}
