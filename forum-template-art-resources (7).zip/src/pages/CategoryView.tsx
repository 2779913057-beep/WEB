import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useForum } from '../context/ForumContext';
import { useAuth } from '../context/AuthContext';
import { format } from 'date-fns';
import { MessageSquare, Eye, Plus, Pin, Gem, RefreshCw, ArrowUpDown } from 'lucide-react';

export const CategoryView: React.FC = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const { categories, getThreadsByCategory, togglePinThread, toggleFeatureThread } = useForum();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [sortBy, setSortBy] = useState<'time' | 'hot'>('time');
  const [featuredPage, setFeaturedPage] = useState(0);
  const FEATURED_PER_PAGE = 4;

  const category = categories.find(c => c.id === categoryId);
  const allThreads = categoryId ? getThreadsByCategory(categoryId) : [];
  
  // Filter visible threads
  const visibleThreads = allThreads.filter(t => {
    if (user?.role === 'admin') return true;
    if (t.isHidden) return false;
    if (t.status && t.status !== 'approved') return false;
    return true;
  });

  // Featured threads (top showcase)
  const featuredThreads = visibleThreads.filter(t => t.isFeatured);
  const featuredTotalPages = Math.ceil(featuredThreads.length / FEATURED_PER_PAGE);
  const displayedFeatured = featuredThreads.slice(
    featuredPage * FEATURED_PER_PAGE, 
    (featuredPage + 1) * FEATURED_PER_PAGE
  );

  // All regular threads (精华贴也要在主列表显示)
  const regularThreads = visibleThreads; // 不过滤精华贴
  
  // Pinned always on top, then sort
  const pinnedThreads = regularThreads.filter(t => t.isPinned);
  const unpinnedThreads = regularThreads.filter(t => !t.isPinned);
  
  const sortedUnpinned = [...unpinnedThreads].sort((a, b) => {
    if (sortBy === 'hot') {
      return (b.views || 0) - (a.views || 0);
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
  
  const sortedThreads = [...pinnedThreads, ...sortedUnpinned];

  if (!category) {
    return <div className="text-center py-12">找不到该板块</div>;
  }

  const handleSwapFeatured = () => {
    setFeaturedPage((featuredPage + 1) % Math.max(1, featuredTotalPages));
  };

  const isAdmin = user?.role === 'admin';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">{category.name}</h1>
          <p className="text-slate-500 mt-1">{category.description}</p>
        </div>
        {user && (
          <Link 
            to={`/create-thread/${category.id}`} 
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md font-medium flex items-center gap-2"
          >
            <Plus className="h-5 w-5" />
            发布新帖
          </Link>
        )}
      </div>

      {/* Featured Section */}
      {featuredThreads.length > 0 && (
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-4">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-bold text-purple-800 flex items-center gap-2">
              <Gem className="h-5 w-5" />
              ✨ 本版精华
            </h2>
            {featuredTotalPages > 1 && (
              <button 
                onClick={handleSwapFeatured}
                className="flex items-center gap-1 text-sm text-purple-600 hover:text-purple-800"
              >
                <RefreshCw className="h-4 w-4" />
                换一批
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {displayedFeatured.map(thread => (
              <Link 
                key={thread.id} 
                to={`/thread/${thread.id}`}
                className="flex items-center gap-3 bg-white p-3 rounded-lg border border-purple-100 hover:border-purple-300 hover:shadow-sm transition-all"
              >
                <div className="flex-shrink-0 w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <Gem className="h-5 w-5 text-purple-600" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-slate-900 truncate">{thread.title}</div>
                  <div className="text-xs text-slate-500">{thread.authorName} • {thread.views || 0} 浏览</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Sort Controls */}
      <div className="flex justify-end">
        <div className="inline-flex items-center gap-2 bg-white border border-slate-200 rounded-lg p-1">
          <ArrowUpDown className="h-4 w-4 text-slate-400 ml-2" />
          <button
            onClick={() => setSortBy('time')}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              sortBy === 'time' ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            最新发布
          </button>
          <button
            onClick={() => setSortBy('hot')}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              sortBy === 'hot' ? 'bg-indigo-100 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            热度最高
          </button>
        </div>
      </div>

      {/* Thread List */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        {sortedThreads.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            暂无帖子。成为第一个发帖的人吧！
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {sortedThreads.map(thread => (
              <div 
                key={thread.id} 
                className="p-4 hover:bg-slate-50 transition-colors cursor-pointer"
                onClick={() => navigate(`/thread/${thread.id}`)}
              >
                <div className="flex items-start gap-4">
                  {/* Cover Image Thumbnail */}
                  {thread.coverImage && (
                    <div className="flex-shrink-0 w-24 h-16 rounded-lg overflow-hidden bg-slate-100">
                      <img 
                        src={thread.coverImage} 
                        alt={thread.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      {thread.isPinned && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-700">
                          <Pin className="h-3 w-3" />
                          置顶
                        </span>
                      )}
                      {thread.isFeatured && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-700">
                          <Gem className="h-3 w-3" />
                          精华
                        </span>
                      )}
                      {thread.rewardConfig && thread.rewardConfig.remainingBudget > 0 && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-orange-100 text-orange-700">
                          🎁 有奖
                        </span>
                      )}
                      <span className="text-lg font-semibold text-slate-900 hover:text-indigo-600 truncate">
                        {thread.title}
                      </span>
                    </div>
                    <div className="mt-1 text-sm text-slate-500 flex items-center gap-2 flex-wrap">
                      <span>作者: <span className="font-medium text-slate-700">{thread.authorName}</span></span>
                      <span>•</span>
                      <span>{format(new Date(thread.createdAt), 'yyyy年MM月dd日')}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    {/* Stats */}
                    <div className="flex items-center gap-4 text-slate-400 text-sm">
                      <div className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        <span>{thread.views || 0}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageSquare className="h-4 w-4" />
                        <span>{thread.replies}</span>
                      </div>
                    </div>
                    
                    {/* Admin Actions */}
                    {isAdmin && (
                      <div className="flex items-center gap-1 border-l border-slate-200 pl-4" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => togglePinThread(thread.id)}
                          className={`p-1.5 rounded transition-colors ${
                            thread.isPinned 
                              ? 'bg-amber-500 text-white' 
                              : 'hover:bg-slate-100 text-slate-400'
                          }`}
                          title={thread.isPinned ? '取消置顶' : '置顶'}
                        >
                          <Pin className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => toggleFeatureThread(thread.id)}
                          className={`p-1.5 rounded transition-colors ${
                            thread.isFeatured 
                              ? 'bg-purple-500 text-white' 
                              : 'hover:bg-slate-100 text-slate-400'
                          }`}
                          title={thread.isFeatured ? '取消精华' : '设为精华'}
                        >
                          <Gem className="h-4 w-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
