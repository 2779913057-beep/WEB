import React from 'react';
import { Heart } from 'lucide-react';

export const Sponsor: React.FC = () => {
  return (
    <div className="max-w-2xl mx-auto text-center space-y-8 py-12">
      <div className="space-y-4">
        <div className="flex justify-center">
           <div className="p-4 bg-red-50 rounded-full">
             <Heart className="h-12 w-12 text-red-500 fill-current" />
           </div>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900">支持 SudoCG 社区</h1>
        <p className="text-lg text-slate-600 max-w-lg mx-auto">
          您的慷慨赞助将帮助我们要维持服务器运行、开发新功能并为社区提供更好的服务。
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col items-center">
           <div className="h-48 w-48 bg-green-500 rounded-lg flex items-center justify-center text-white font-bold text-xl mb-4">
             微信支付 QR
           </div>
           <p className="font-medium text-slate-900">微信支付</p>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col items-center">
           <div className="h-48 w-48 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold text-xl mb-4">
             支付宝 QR
           </div>
           <p className="font-medium text-slate-900">支付宝</p>
        </div>
      </div>
      
      <div className="text-sm text-slate-500 pt-8">
        感谢每一位支持者的贡献！
      </div>
    </div>
  );
};
