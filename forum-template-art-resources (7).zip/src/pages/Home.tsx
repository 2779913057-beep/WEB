import React, { useState } from 'react';
import { useForum } from '../context/ForumContext';
import { Link, useSearchParams } from 'react-router-dom';
import * as Icons from 'lucide-react';
import { format } from 'date-fns';
import { Plus, Trash2, Flame, Clock, BarChart, Calendar, Pin, RefreshCw } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ContentBlock } from '../types';

export const Home: React.FC = () => {
  const { categories, getThreadsByCategory, addCategory, deleteCategory, threads, siteVisits, dailyVisits } = useForum();
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('q');
  const { user } = useAuth();
  
  const [isCreatingCategory, setIsCreatingCategory] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('');
  const [newCatColor, setNewCatColor] = useState('bg-slate-500');
  
  // 图标上传处理
  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // 检查文件类型
    if (!file.type.includes('png') && !file.type.includes('image')) {
      alert('请上传 PNG 格式的图片');
      return;
    }
    
    // 检查文件大小 (最大 50KB)
    if (file.size > 50 * 1024) {
      alert('图标大小不能超过 50KB');
      return;
    }
    
    const reader = new FileReader();
    reader.onloadend = () => {
      setNewCatIcon(reader.result as string);
    };
    reader.readAsDataURL(file);
  };
  const [activeTab, setActiveTab] = useState<'hot' | 'new'>('hot');
  const [hotPage, setHotPage] = useState(0);
  const [newPage, setNewPage] = useState(0);

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCatName && newCatDesc) {
      addCategory(newCatName, newCatDesc, newCatIcon, newCatColor);
      setIsCreatingCategory(false);
      setNewCatName('');
      setNewCatDesc('');
      setNewCatIcon('Folder');
      setNewCatColor('bg-slate-500');
    }
  };

  const getThreadContentPreview = (blocks: ContentBlock[]) => {
    return blocks
      .filter(b => b.type === 'text' || b.type === 'header')
      .map(b => b.value)
      .join(' ')
      .slice(0, 200);
  };

  // Filter threads for display
  const allVisibleThreads = threads.filter(t => {
    if (user?.role === 'admin') return true;
    if (t.isHidden) return false;
    if (t.status && t.status !== 'approved') return false;
    return true;
  });

  // Pinned threads for showcase
  const pinnedThreads = allVisibleThreads.filter(t => t.isPinned);
  
  // Hot & New with pagination (10 per page)
  const ITEMS_PER_PAGE = 10;
  
  const hotThreadsAll = [...allVisibleThreads]
    .filter(t => !t.isPinned) // Exclude pinned from regular lists
    .sort((a, b) => (b.views || 0) - (a.views || 0));
  const hotThreads = hotThreadsAll.slice(hotPage * ITEMS_PER_PAGE, (hotPage + 1) * ITEMS_PER_PAGE);
  const hotTotalPages = Math.ceil(hotThreadsAll.length / ITEMS_PER_PAGE);

  const newThreadsAll = [...allVisibleThreads]
    .filter(t => !t.isPinned)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const newThreads = newThreadsAll.slice(newPage * ITEMS_PER_PAGE, (newPage + 1) * ITEMS_PER_PAGE);
  const newTotalPages = Math.ceil(newThreadsAll.length / ITEMS_PER_PAGE);

  const displayThreads = activeTab === 'hot' ? hotThreads : newThreads;

  const handleSwap = () => {
    if (activeTab === 'hot') {
      setHotPage((hotPage + 1) % Math.max(1, hotTotalPages));
    } else {
      setNewPage((newPage + 1) % Math.max(1, newTotalPages));
    }
  };

  // Fuzzy search helper function
  const fuzzyMatch = (text: string, query: string): boolean => {
    const lowerText = text.toLowerCase();
    const lowerQuery = query.toLowerCase();
    
    // Direct match
    if (lowerText.includes(lowerQuery)) return true;
    
    // Split query into words and check if all words exist
    const queryWords = lowerQuery.split(/\s+/).filter(w => w.length > 0);
    return queryWords.every(word => lowerText.includes(word));
  };

  // Get all users for user search
  const { getAllUsers } = useAuth();
  const allUsers = getAllUsers ? getAllUsers() : [];

  if (searchQuery) {
    // Search users by ID, username, or nickname
    const matchedUsers = allUsers.filter(u => {
      const query = searchQuery.toLowerCase();
      return u.id.toLowerCase().includes(query) ||
             u.username.toLowerCase().includes(query) ||
             (u.nickname && u.nickname.toLowerCase().includes(query));
    });

    // Filter threads by title, content, or author
    const filteredThreads = threads.filter(t => {
      if (t.isHidden && user?.role !== 'admin') return false;
      if (t.status && t.status !== 'approved' && user?.role !== 'admin') return false;
      
      const contentString = getThreadContentPreview(t.blocks || []);
      
      // Title fuzzy match
      const titleMatch = fuzzyMatch(t.title, searchQuery);
      
      // Content fuzzy match
      const contentMatch = fuzzyMatch(contentString, searchQuery);
      
      // Author fuzzy match (by name)
      const authorMatch = fuzzyMatch(t.authorName, searchQuery);
      
      // Author match by ID
      const authorIdMatch = matchedUsers.some(u => u.id === t.authorId);
      
      return titleMatch || contentMatch || authorMatch || authorIdMatch;
    });

    // Threads from matched users
    const userThreads = matchedUsers.length > 0 
      ? threads.filter(t => matchedUsers.some(u => u.id === t.authorId) && 
          (!t.isHidden || user?.role === 'admin') &&
          (!t.status || t.status === 'approved' || user?.role === 'admin'))
      : [];

    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-slate-900">搜索结果: "{searchQuery}"</h2>
        
        {/* User Search Results */}
        {matchedUsers.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
            <h3 className="text-lg font-semibold text-slate-800 mb-3 flex items-center gap-2">
              <Icons.Users className="h-5 w-5 text-indigo-500" />
              匹配的用户 ({matchedUsers.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {matchedUsers.slice(0, 6).map(u => (
                <Link 
                  key={u.id} 
                  to={`/profile/${u.id}`}
                  className="flex items-center gap-3 p-3 rounded-lg border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50/30 transition-all"
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white font-bold">
                    {(u.nickname || u.username).charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-medium text-slate-900">{u.nickname || u.username}</div>
                    <div className="text-xs text-slate-500">@{u.username} • ID: {u.id.slice(0, 8)}...</div>
                  </div>
                </Link>
              ))}
            </div>
            {matchedUsers.length > 0 && (
              <p className="text-sm text-slate-500 mt-3">
                该用户共发布 {userThreads.length} 篇帖子
              </p>
            )}
          </div>
        )}

        {/* Thread Search Results */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200">
          <div className="p-4 border-b border-slate-200">
            <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
              <Icons.FileText className="h-5 w-5 text-indigo-500" />
              匹配的帖子 ({filteredThreads.length})
            </h3>
          </div>
          {filteredThreads.length === 0 ? (
            <div className="p-8 text-center text-slate-500">没有找到匹配的帖子</div>
          ) : (
            <div className="divide-y divide-slate-200">
              {filteredThreads.map(thread => {
                const contentPreview = getThreadContentPreview(thread.blocks || []);
                return (
                  <div key={thread.id} className="p-4 hover:bg-slate-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          {thread.isPinned && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-700">
                              <Pin className="h-3 w-3" /> 置顶
                            </span>
                          )}
                          {thread.isFeatured && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-700">
                              <Icons.Gem className="h-3 w-3" /> 精华
                            </span>
                          )}
                          <Link to={`/thread/${thread.id}`} className="text-lg font-semibold text-slate-900 hover:text-indigo-600">
                            {thread.title}
                          </Link>
                          {thread.isHidden && <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded">隐藏</span>}
                        </div>
                        {contentPreview && (
                          <p className="mt-1 text-sm text-slate-600 line-clamp-2">{contentPreview.slice(0, 150)}...</p>
                        )}
                        <div className="mt-2 text-sm text-slate-500 flex items-center gap-2 flex-wrap">
                          <Link to={`/profile/${thread.authorId}`} className="font-medium text-slate-700 hover:text-indigo-600">
                            {thread.authorName}
                          </Link>
                          <span>•</span>
                          <span>{format(new Date(thread.createdAt), 'yyyy年MM月dd日')}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Icons.Eye className="h-3 w-3" /> {thread.views || 0}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Icons.MessageSquare className="h-3 w-3" /> {thread.replies}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        
        <Link to="/" className="inline-flex items-center gap-2 text-indigo-600 hover:underline">
          <Icons.ArrowLeft className="h-4 w-4" />
          返回首页
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Hero Section - Compact */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-8 rounded-xl shadow-lg text-center text-white relative overflow-hidden">
        <div className="relative z-10">
          <h1 className="text-3xl font-extrabold mb-2">欢迎来到 SudoCG 社区</h1>
          <p className="text-indigo-100 max-w-2xl mx-auto mb-4">
            专业的 CG 艺术家交流平台
          </p>
          <div className="flex justify-center gap-4">
            <Link to="/sponsor" className="bg-yellow-500 hover:bg-yellow-400 text-white px-5 py-2 rounded-full font-bold shadow-lg transition-transform hover:scale-105 flex items-center gap-2 text-sm">
               <Icons.Heart className="h-4 w-4 fill-current" />
               赞助我们
            </Link>
          </div>
          <div className="mt-4 flex justify-center gap-4 text-xs font-medium">
             <div className="inline-flex items-center gap-1 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
               <BarChart className="h-3 w-3" />
               总访问: {siteVisits}
             </div>
             <div className="inline-flex items-center gap-1 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
               <Calendar className="h-3 w-3" />
               今日: {dailyVisits}
             </div>
          </div>
        </div>
      </div>

      {/* Pinned Section */}
      {pinnedThreads.length > 0 && (
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-lg p-4">
          <h2 className="text-lg font-bold text-amber-800 mb-3 flex items-center gap-2">
            <Pin className="h-5 w-5" />
            置顶推荐
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pinnedThreads.slice(0, 4).map(thread => (
              <Link 
                key={thread.id} 
                to={`/thread/${thread.id}`}
                className="flex items-center gap-3 bg-white p-3 rounded-lg border border-amber-100 hover:border-amber-300 hover:shadow-sm transition-all"
              >
                <div className="flex-shrink-0 w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
                  <Pin className="h-4 w-4 text-amber-600" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-slate-900 truncate">{thread.title}</div>
                  <div className="text-xs text-slate-500">{thread.authorName} • {thread.replies} 回复</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Hot & New Section - 2 Column Grid */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex border-b border-slate-200">
            <button
                onClick={() => setActiveTab('hot')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium transition-colors ${
                    activeTab === 'hot' 
                    ? 'bg-white text-indigo-600 border-b-2 border-indigo-600' 
                    : 'bg-slate-50 text-slate-500 hover:text-slate-700'
                }`}
            >
                <Flame className={`h-4 w-4 ${activeTab === 'hot' ? 'text-orange-500' : ''}`} />
                热门帖子 (按浏览量)
            </button>
            <button
                onClick={() => setActiveTab('new')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium transition-colors ${
                    activeTab === 'new' 
                    ? 'bg-white text-indigo-600 border-b-2 border-indigo-600' 
                    : 'bg-slate-50 text-slate-500 hover:text-slate-700'
                }`}
            >
                <Clock className={`h-4 w-4 ${activeTab === 'new' ? 'text-blue-500' : ''}`} />
                最新发布
            </button>
        </div>
        
        <div className="p-4">
          {displayThreads.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {displayThreads.map(thread => (
                <Link 
                  key={thread.id} 
                  to={`/thread/${thread.id}`}
                  className="block rounded-lg border border-slate-100 hover:border-indigo-200 hover:shadow-md transition-all overflow-hidden"
                >
                  {/* Cover Image */}
                  {thread.coverImage && (
                    <div className="w-full h-32 overflow-hidden">
                      <img 
                        src={thread.coverImage} 
                        alt={thread.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="p-3">
                    <div className="flex items-start gap-3">
                      {!thread.coverImage && (
                        <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center text-xs font-bold ${
                          activeTab === 'hot' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'
                        }`}>
                          {activeTab === 'hot' ? (thread.views || 0) : 'New'}
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="font-medium text-slate-900 truncate">{thread.title}</div>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                          <span>{thread.authorName}</span>
                          <span>•</span>
                          <span>{format(new Date(thread.createdAt), 'MM-dd')}</span>
                          <span>•</span>
                          <span><Icons.Eye className="inline h-3 w-3" /> {thread.views || 0}</span>
                          <span>•</span>
                          <span>{thread.replies} 回复</span>
                          {thread.rewardConfig && thread.rewardConfig.remainingBudget > 0 && (
                            <span className="text-orange-500 font-medium">🎁 有奖</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500">暂无帖子</div>
          )}
          
          {/* Swap Button */}
          {(activeTab === 'hot' ? hotTotalPages : newTotalPages) > 1 && (
            <div className="flex justify-center mt-4">
              <button 
                onClick={handleSwap}
                className="flex items-center gap-2 px-4 py-2 text-sm text-indigo-600 hover:bg-indigo-50 rounded-full border border-indigo-200 transition-colors"
              >
                <RefreshCw className="h-4 w-4" />
                换一批
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Categories Section - 2 Column */}
      <div>
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-slate-800">板块列表</h2>
            {user?.role === 'admin' && (
            <button 
                onClick={() => setIsCreatingCategory(!isCreatingCategory)}
                className="flex items-center gap-2 text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
                <Plus className="h-4 w-4" />
                创建新板块
            </button>
            )}
        </div>

        {isCreatingCategory && (
            <form onSubmit={handleCreateCategory} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 mb-6">
            <h3 className="text-lg font-medium text-slate-900 mb-4">创建新板块</h3>
            <div className="space-y-4">
                <div>
                <label className="block text-sm font-medium text-slate-700">板块名称</label>
                <input 
                    type="text" 
                    value={newCatName} 
                    onChange={e => setNewCatName(e.target.value)}
                    className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                    required
                />
                </div>
                <div>
                <label className="block text-sm font-medium text-slate-700">描述</label>
                <input 
                    type="text" 
                    value={newCatDesc} 
                    onChange={e => setNewCatDesc(e.target.value)}
                    className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                    required
                />
                </div>
                <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">板块图标 (PNG, 最大 50KB)</label>
                <div className="flex items-center gap-4">
                  {newCatIcon ? (
                    <div className="relative">
                      <img src={newCatIcon} alt="图标预览" className="w-16 h-16 object-contain rounded-lg border border-slate-200 bg-slate-50" />
                      <button
                        type="button"
                        onClick={() => setNewCatIcon('')}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs hover:bg-red-600"
                      >
                        ×
                      </button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center w-16 h-16 border-2 border-dashed border-slate-300 rounded-lg cursor-pointer hover:border-indigo-400 hover:bg-indigo-50 transition-colors">
                      <Icons.Upload className="h-5 w-5 text-slate-400" />
                      <span className="text-xs text-slate-400 mt-1">上传</span>
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/gif"
                        onChange={handleIconUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                  <div className="text-sm text-slate-500">
                    <p>• 支持 PNG、JPG、GIF 格式</p>
                    <p>• 建议尺寸: 64x64 像素</p>
                    <p>• 文件大小不超过 50KB</p>
                  </div>
                </div>
                </div>
                <div>
                <label className="block text-sm font-medium text-slate-700">颜色</label>
                <select 
                    value={newCatColor}
                    onChange={e => setNewCatColor(e.target.value)}
                    className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                >
                    <option value="bg-blue-500">🔵 蓝色 (Blue)</option>
                    <option value="bg-red-500">🔴 红色 (Red)</option>
                    <option value="bg-green-500">🟢 绿色 (Green)</option>
                    <option value="bg-yellow-500">🟡 黄色 (Yellow)</option>
                    <option value="bg-purple-500">🟣 紫色 (Purple)</option>
                    <option value="bg-pink-500">🌸 粉色 (Pink)</option>
                    <option value="bg-orange-500">🟠 橙色 (Orange)</option>
                    <option value="bg-slate-500">⚪ 灰色 (Slate)</option>
                    <option value="bg-indigo-500">💙 靛蓝 (Indigo)</option>
                </select>
                </div>
                <div className="flex justify-end gap-2">
                <button 
                    type="button" 
                    onClick={() => setIsCreatingCategory(false)}
                    className="px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 border border-slate-300 rounded-md"
                >
                    取消
                </button>
                <button 
                    type="submit" 
                    className="px-4 py-2 text-sm text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                >
                    创建
                </button>
                </div>
            </div>
            </form>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {categories.map((category) => {
            const IconComponent = (Icons as any)[category.icon] || Icons.Folder;
            const categoryThreads = getThreadsByCategory(category.id);
            const visibleThreads = categoryThreads.filter(t => !t.isHidden || user?.role === 'admin');
            const latestThread = visibleThreads[0];

            return (
                <div key={category.id} className="bg-white rounded-lg shadow-sm border border-slate-200 hover:shadow-md transition-shadow relative group">
                <div className="p-5">
                    <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-lg ${category.color} bg-opacity-10 flex-shrink-0`}>
                        {category.icon && category.icon.startsWith('data:') ? (
                          <img src={category.icon} alt={category.name} className="h-6 w-6 object-contain" />
                        ) : (
                          <IconComponent className={`h-6 w-6 ${category.color.replace('bg-', 'text-')}`} />
                        )}
                    </div>
                    <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start">
                        <Link to={`/category/${category.id}`} className="text-lg font-bold text-slate-900 hover:text-indigo-600">
                            {category.name}
                        </Link>
                        {user?.role === 'admin' && (
                            <button
                            onClick={(e) => {
                                e.preventDefault();
                                if(window.confirm('确定要删除这个板块吗？')) deleteCategory(category.id);
                            }}
                            className="p-1 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            title="删除板块"
                            >
                            <Trash2 className="h-4 w-4" />
                            </button>
                        )}
                        </div>
                        <p className="text-slate-500 text-sm mt-1 truncate">{category.description}</p>
                        
                        <div className="mt-3 flex items-center gap-4 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                            <Icons.MessageSquare className="h-3 w-3" />
                            {visibleThreads.length} 帖子
                        </span>
                        {latestThread && (
                          <span className="truncate">
                            最新: {latestThread.title.slice(0, 15)}...
                          </span>
                        )}
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            );
            })}
        </div>
      </div>
    </div>
  );
};
