import React from 'react';
import { Link } from 'react-router-dom';
import { useForum } from '../context/ForumContext';
import { useAuth } from '../context/AuthContext';
import { format } from 'date-fns';
import { Bookmark, Eye, MessageSquare, Trash2, ArrowLeft } from 'lucide-react';

export const Favorites: React.FC = () => {
  const { threads } = useForum();
  const { user, removeFavorite } = useAuth();

  if (!user) {
    return (
      <div className="text-center py-12">
        <Bookmark className="h-16 w-16 text-slate-300 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-700 mb-2">请先登录</h2>
        <p className="text-slate-500 mb-4">登录后即可查看您的收藏夹</p>
        <Link to="/login" className="text-indigo-600 hover:underline font-medium">
          去登录
        </Link>
      </div>
    );
  }

  const favoriteThreads = threads.filter(t => 
    user.favorites?.includes(t.id) && !t.isHidden && t.status !== 'rejected'
  );

  const handleRemove = (threadId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (window.confirm('确定要取消收藏吗？')) {
      removeFavorite(threadId);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-yellow-100 rounded-full">
            <Bookmark className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">我的收藏</h1>
            <p className="text-slate-500 text-sm">共 {favoriteThreads.length} 篇收藏</p>
          </div>
        </div>
        <Link 
          to="/" 
          className="flex items-center gap-2 text-slate-600 hover:text-indigo-600 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          返回首页
        </Link>
      </div>

      {/* Favorites List */}
      {favoriteThreads.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-12 text-center">
          <Bookmark className="h-16 w-16 text-slate-200 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-700 mb-2">收藏夹是空的</h3>
          <p className="text-slate-500 mb-4">浏览帖子时点击收藏按钮，即可将喜欢的内容保存到这里</p>
          <Link 
            to="/" 
            className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-md font-medium"
          >
            去发现内容
          </Link>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
          <div className="divide-y divide-slate-200">
            {favoriteThreads.map(thread => (
              <div 
                key={thread.id} 
                className="p-4 hover:bg-slate-50 transition-colors group"
              >
                <Link to={`/thread/${thread.id}`} className="flex items-start gap-4">
                  {/* Cover Image */}
                  {thread.coverImage ? (
                    <div className="flex-shrink-0 w-32 h-20 rounded-lg overflow-hidden bg-slate-100">
                      <img 
                        src={thread.coverImage} 
                        alt={thread.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="flex-shrink-0 w-32 h-20 rounded-lg bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center">
                      <Bookmark className="h-8 w-8 text-indigo-300" />
                    </div>
                  )}
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold text-slate-900 hover:text-indigo-600 truncate">
                      {thread.title}
                    </h3>
                    <div className="mt-1 text-sm text-slate-500 flex items-center gap-2 flex-wrap">
                      <span>作者: <span className="font-medium text-slate-700">{thread.authorName}</span></span>
                      <span>•</span>
                      <span>{format(new Date(thread.createdAt), 'yyyy年MM月dd日')}</span>
                    </div>
                    <div className="mt-2 flex items-center gap-4 text-xs text-slate-400">
                      <div className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        <span>{thread.views || 0}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageSquare className="h-3 w-3" />
                        <span>{thread.replies}</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Remove Button */}
                  <button
                    onClick={(e) => handleRemove(thread.id, e)}
                    className="flex-shrink-0 p-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                    title="取消收藏"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
