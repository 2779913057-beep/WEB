import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useForum } from '../context/ForumContext';
import { Link, useParams } from 'react-router-dom';
import { Shield, Coins, ShoppingBag, Upload, Key, RefreshCw, FileText, Gift, Users, Copy } from 'lucide-react';

export const Profile: React.FC = () => {
  const { user, updateAvatar, changePassword, getAllUsers, redeemCode } = useAuth();
  const { threads } = useForum();
  const { userId: paramUserId } = useParams<{ userId: string }>();
  
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState('');
  const [avatarError, setAvatarError] = useState('');

  // Redemption State
  const [redeemInput, setRedeemInput] = useState('');
  const [redeemMsg, setRedeemMsg] = useState('');
  const [redeemSuccess, setRedeemSuccess] = useState(false);

  // Determine which user profile to show
  const isSelf = !paramUserId || (user && user.id === paramUserId);
  const displayUser = isSelf ? user : getAllUsers().find(u => u.id === paramUserId);

  if (!displayUser) {
    return <div className="text-center py-12">用户不存在或请先登录</div>;
  }

  // Filter threads by the DISPLAYED user
  const userThreads = threads.filter(t => t.authorId === displayUser.id && (t.status === 'approved' || user?.role === 'admin' || isSelf));
  const purchasedThreads = isSelf && user ? threads.filter(t => user.purchasedThreads?.includes(t.id)) : [];

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isSelf) return;
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 100 * 1024) {
        setAvatarError('图片大小不能超过 100KB');
        return;
      }
      setAvatarError('');
      const reader = new FileReader();
      reader.onloadend = () => {
        updateAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    const result = redeemCode(redeemInput);
    
    if (result.success) {
      setRedeemSuccess(true);
      setRedeemMsg(result.message);
      setRedeemInput('');
    } else {
      setRedeemSuccess(false);
      setRedeemMsg(result.message);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMsg('');
    const result = await changePassword(securityAnswer, newPassword);
    setPasswordMsg(result.message);
    if (result.success) {
        setSecurityAnswer('');
        setNewPassword('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* User Info Card */}
      <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-200 flex flex-col sm:flex-row items-start gap-8">
        <div className="flex flex-col items-center gap-4">
          <div className="relative group">
            <img 
              src={displayUser.avatar} 
              alt={displayUser.username} 
              className="w-32 h-32 rounded-full bg-slate-100 object-cover"
            />
            {isSelf && (
              <label className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white rounded-full opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity">
                <Upload className="h-6 w-6" />
                <input type="file" className="hidden" accept="image/*" onChange={handleAvatarChange} />
              </label>
            )}
          </div>
          {isSelf && avatarError && <p className="text-red-500 text-xs">{avatarError}</p>}
        </div>

        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{displayUser.nickname || displayUser.username}</h1>
            <p className="text-slate-500">@{displayUser.username}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-slate-600">
             <div className="flex items-center gap-2">
                <span className="font-semibold">性别:</span> 
                {displayUser.gender === 'male' ? '男' : displayUser.gender === 'female' ? '女' : '其他'}
             </div>
             <div className="flex items-center gap-2">
                <span className="font-semibold">手机:</span> {displayUser.phone || '未设置'}
             </div>
             <div className="flex items-center gap-2">
                <span className="font-semibold">邮箱:</span> {displayUser.email || '未设置'}
             </div>
             <div className="flex items-center gap-2">
                <span className="font-semibold">注册时间:</span> {new Date(displayUser.createdAt).toLocaleDateString()}
             </div>
             <div className="flex items-center gap-2">
                <span className="font-semibold">粉丝:</span> {displayUser.followers?.length || 0}
             </div>
             <div className="flex items-center gap-2">
                <span className="font-semibold">关注:</span> {displayUser.follows?.length || 0}
             </div>
          </div>
          
          <div className="flex flex-wrap gap-4 pt-2">
            <div className="flex items-center gap-1 bg-slate-100 px-3 py-1 rounded-full text-sm font-medium text-slate-700">
              <Shield className="h-4 w-4" />
              {displayUser.role === 'admin' ? '管理员' : '会员'}
            </div>
            <div className="flex items-center gap-1 bg-yellow-100 px-3 py-1 rounded-full text-sm font-medium text-yellow-800">
              <Coins className="h-4 w-4" />
              {displayUser.points || 0} 积分
            </div>
            {displayUser.inviteCount !== undefined && displayUser.inviteCount > 0 && (
              <div className="flex items-center gap-1 bg-green-100 px-3 py-1 rounded-full text-sm font-medium text-green-800">
                <Users className="h-4 w-4" />
                已邀请 {displayUser.inviteCount} 人
              </div>
            )}
          </div>

          {/* Invite Code Section - visible to self only */}
          {isSelf && displayUser.inviteCode && (
            <div className="mt-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
              <div className="flex items-center gap-2 mb-2">
                <Gift className="h-5 w-5 text-green-600" />
                <span className="font-bold text-green-800">我的邀请码</span>
              </div>
              <div className="flex items-center gap-3">
                <code className="bg-white px-4 py-2 rounded border border-green-300 font-mono text-lg text-green-700">
                  {displayUser.inviteCode}
                </code>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(displayUser.inviteCode || '');
                    alert('邀请码已复制到剪贴板！');
                  }}
                  className="flex items-center gap-1 text-sm text-green-600 hover:text-green-800"
                >
                  <Copy className="h-4 w-4" />
                  复制
                </button>
              </div>
              <p className="text-xs text-green-600 mt-2">
                分享给朋友注册时填写：
                <br />• 您将获得 <strong>50 积分</strong> 奖励
                <br />• 对方将获得 <strong>30 积分</strong> 额外奖励
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Published Threads (Everyone can see) */}
      <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-200">
        <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
          <FileText className="h-5 w-5" />
          发布的帖子
        </h2>
        {userThreads.length > 0 ? (
          <div className="space-y-4">
            {userThreads.map(thread => (
              <div key={thread.id} className="flex justify-between items-center p-4 bg-slate-50 rounded border border-slate-100">
                <Link to={`/thread/${thread.id}`} className="font-medium text-slate-900 hover:text-indigo-600">
                  {thread.title}
                </Link>
                <div className="text-sm text-slate-500 flex gap-4">
                   <span>回复: {thread.replies}</span>
                   <span>{new Date(thread.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 text-center py-8">暂无发布记录</p>
        )}
      </div>

      {/* Private Sections (Only Self) */}
      {isSelf && user && (
        <>
           {/* Redeem Code Section */}
           <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-200">
            <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Coins className="h-5 w-5" />
              积分兑换
            </h2>
            <form onSubmit={handleRedeem} className="flex gap-4 max-w-md items-start">
              <div className="flex-1">
                <input 
                    type="text" 
                    value={redeemInput}
                    onChange={e => setRedeemInput(e.target.value)}
                    placeholder="输入兑换码"
                    className="block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                />
                {redeemMsg && (
                    <p className={`mt-2 text-sm ${redeemSuccess ? 'text-green-600' : 'text-red-600'}`}>
                        {redeemMsg}
                    </p>
                )}
              </div>
              <button 
                  type="submit"
                  className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors text-sm font-medium whitespace-nowrap"
              >
                  兑换
              </button>
            </form>
            <div className="mt-4 text-sm text-slate-500">
                需要积分？您可以 <Link to="/sponsor" className="text-indigo-600 hover:underline">赞助我们</Link> 获取兑换码，或通过发帖活跃赚取积分。
            </div>
           </div>

          {/* Change Password Section */}
          <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-200">
            <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Key className="h-5 w-5" />
              修改密码
            </h2>
            <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
                <div className="text-sm text-slate-500 mb-4">
                    为了安全，您每天只能修改2次密码。验证密保答案后即可修改。
                    <br />
                    <span className="font-medium text-slate-700">密保问题: {user.securityQuestion || '未设置'}</span>
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700">密保答案</label>
                    <input 
                        type="text" 
                        value={securityAnswer}
                        onChange={e => setSecurityAnswer(e.target.value)}
                        className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                        required
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700">新密码</label>
                    <input 
                        type="password" 
                        value={newPassword}
                        onChange={e => setNewPassword(e.target.value)}
                        className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                        required
                        minLength={6}
                    />
                </div>
                <button 
                    type="submit" 
                    className="flex items-center justify-center gap-2 w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-slate-800 hover:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500"
                >
                    <RefreshCw className="h-4 w-4" />
                    确认修改
                </button>
                {passwordMsg && (
                    <div className={`text-sm text-center ${passwordMsg.includes('成功') ? 'text-green-600' : 'text-red-600'}`}>
                        {passwordMsg}
                    </div>
                )}
            </form>
          </div>

          {/* Purchased Content */}
          <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-200">
            <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <ShoppingBag className="h-5 w-5" />
              已购买的内容
            </h2>
            
            {purchasedThreads.length > 0 ? (
              <div className="space-y-4">
                {purchasedThreads.map(thread => (
                  <div key={thread.id} className="flex justify-between items-center p-4 bg-slate-50 rounded border border-slate-100">
                    <Link to={`/thread/${thread.id}`} className="font-medium text-slate-900 hover:text-indigo-600">
                      {thread.title}
                    </Link>
                    <span className="text-sm text-slate-500">
                      {new Date(thread.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-slate-500 text-center py-8">暂无购买记录</p>
            )}
          </div>
        </>
      )}
    </div>
  );
};
