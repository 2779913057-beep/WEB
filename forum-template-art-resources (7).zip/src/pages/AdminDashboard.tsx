import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useForum } from '../context/ForumContext';
import { useNavigate, Link } from 'react-router-dom';
import { User } from '../types';
import { Trash2, Folder, MessageSquare, Users, Lock, Ban, CheckCircle, ShieldAlert, XCircle, Ticket, ExternalLink, Settings } from 'lucide-react';
import { format } from 'date-fns';

export const AdminDashboard: React.FC = () => {
  const { user, getAllUsers, deleteUser, updateUserStatus, resetUserPassword, redemptionCodes, generateRedemptionCode } = useAuth();
  const { threads, categories, deleteCategory, deleteThread, restoreThread, permanentlyDeleteThread, approveThread, rejectThread, bannedKeywords, addBannedKeyword, removeBannedKeyword, moderationRules, updateModerationRules, togglePinThread, toggleFeatureThread, toggleThreadVisibility } = useForum();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'users' | 'threads' | 'categories' | 'audit' | 'system'>('users');
  const [users, setUsers] = useState<User[]>([]);
  
  // System Tab State
  const [pointsToGenerate, setPointsToGenerate] = useState<number>(100);
  const [generatedCode, setGeneratedCode] = useState<string>('');
  
  // Audit Tab State
  const [newKeyword, setNewKeyword] = useState('');

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    setUsers(getAllUsers());
  }, [user, navigate, getAllUsers, activeTab]); 

  const refreshUsers = () => {
    setUsers(getAllUsers());
  };

  const handleGenerateCode = (e: React.FormEvent) => {
    e.preventDefault();
    const code = generateRedemptionCode(pointsToGenerate);
    setGeneratedCode(code);
  };

  if (!user || user.role !== 'admin') return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-900">管理后台</h1>
      </div>

      <div className="flex gap-4 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'users' ? 'bg-indigo-50 text-indigo-700 font-medium' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          <Users size={18} />
          用户管理
        </button>
        <button
          onClick={() => setActiveTab('threads')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'threads' ? 'bg-indigo-50 text-indigo-700 font-medium' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          <MessageSquare size={18} />
          帖子管理
        </button>
        <button
          onClick={() => setActiveTab('categories')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'categories' ? 'bg-indigo-50 text-indigo-700 font-medium' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          <Folder size={18} />
          板块管理
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'audit' ? 'bg-indigo-50 text-indigo-700 font-medium' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          <ShieldAlert size={18} />
          内容审核
        </button>
        <button
          onClick={() => setActiveTab('system')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${activeTab === 'system' ? 'bg-indigo-50 text-indigo-700 font-medium' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          <Ticket size={18} />
          系统 & 兑换码
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
        {/* Audit Tab */}
        {activeTab === 'audit' && (
          <div>
            {/* 1. Pending List */}
            <div className="overflow-x-auto border-b border-slate-200">
               <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">待审核内容</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">作者</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">提交时间</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">操作</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {threads.filter(t => t.status === 'pending').length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-4 text-center text-slate-500">
                        当前没有待审核的内容
                      </td>
                    </tr>
                  ) : (
                    threads.filter(t => t.status === 'pending').map((t) => (
                      <tr key={t.id}>
                        <td className="px-6 py-4">
                          <div className="text-sm text-slate-900 font-medium truncate max-w-xs" title={t.title}>{t.title}</div>
                          <div className="text-xs text-slate-500 mt-1">
                            包含敏感词/链接/多媒体，系统自动拦截
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          {t.authorName}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          {format(new Date(t.createdAt), 'yyyy-MM-dd HH:mm')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex gap-2">
                           <button 
                             onClick={() => approveThread(t.id)}
                             className="text-green-600 hover:text-green-900 flex items-center gap-1"
                             title="通过"
                           >
                             <CheckCircle size={18} /> 通过
                           </button>
                           <button 
                             onClick={() => rejectThread(t.id)}
                             className="text-red-600 hover:text-red-900 flex items-center gap-1"
                             title="拒绝"
                           >
                             <XCircle size={18} /> 拒绝
                           </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-0 divide-x divide-slate-200">
              {/* 2. Moderation Rules Config */}
              <div className="p-6">
                <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  审核规则配置 (Moderation Rules)
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="requireMediaReview"
                        name="requireMediaReview"
                        type="checkbox"
                        checked={moderationRules.requireMediaReview}
                        onChange={(e) => updateModerationRules({...moderationRules, requireMediaReview: e.target.checked})}
                        className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-slate-300 rounded"
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label htmlFor="requireMediaReview" className="font-medium text-slate-700">人工审核图片/视频</label>
                      <p className="text-slate-500">若勾选，包含图片或视频的帖子/回复将自动进入待审核状态。</p>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="autoApproveTimeout" className="block text-sm font-medium text-slate-700">超时自动通过 (小时)</label>
                    <div className="mt-1 flex rounded-md shadow-sm w-32">
                      <input
                        type="number"
                        name="autoApproveTimeout"
                        id="autoApproveTimeout"
                        min="0"
                        value={moderationRules.autoApproveTimeout}
                        onChange={(e) => updateModerationRules({...moderationRules, autoApproveTimeout: parseInt(e.target.value) || 0})}
                        className="focus:ring-indigo-500 focus:border-indigo-500 flex-1 block w-full rounded-md sm:text-sm border-slate-300 p-2 border"
                      />
                    </div>
                    <p className="mt-1 text-xs text-slate-500">设置为 0 则禁用自动通过功能。</p>
                  </div>
                </div>
              </div>

              {/* 3. Banned Keywords */}
              <div className="p-6">
                <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <ShieldAlert className="h-5 w-5" />
                  敏感词管理
                </h3>
                <p className="text-sm text-slate-500 mb-4">
                  添加的敏感词将用于自动拦截包含这些词汇的帖子和回复。
                </p>
                
                <div className="flex gap-2 mb-6">
                  <input
                    type="text"
                    value={newKeyword}
                    onChange={(e) => setNewKeyword(e.target.value)}
                    placeholder="输入敏感词..."
                    className="flex-1 rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                  />
                  <button
                    onClick={() => {
                      if (newKeyword.trim()) {
                        addBannedKeyword(newKeyword.trim());
                        setNewKeyword('');
                      }
                    }}
                    className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 font-medium"
                  >
                    添加
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {bannedKeywords.length === 0 ? (
                    <span className="text-slate-500 text-sm italic">暂无设置敏感词</span>
                  ) : (
                    bannedKeywords.map((keyword) => (
                      <span key={keyword} className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                        {keyword}
                        <button
                          onClick={() => removeBannedKeyword(keyword)}
                          className="ml-1 text-red-600 hover:text-red-900 focus:outline-none"
                          title="移除"
                        >
                          <XCircle size={14} />
                        </button>
                      </span>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* System & Codes Tab */}
        {activeTab === 'system' && (
          <div className="p-6 space-y-8">
            {/* Generate Code Section */}
            <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
              <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Ticket className="h-5 w-5" />
                生成兑换码
              </h3>
              <form onSubmit={handleGenerateCode} className="flex gap-4 items-end">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">积分面额</label>
                  <input 
                    type="number" 
                    value={pointsToGenerate}
                    onChange={e => setPointsToGenerate(parseInt(e.target.value) || 0)}
                    className="block w-40 rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                  />
                </div>
                <button 
                  type="submit" 
                  className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 font-medium"
                >
                  生成
                </button>
              </form>
              
              {generatedCode && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded text-green-800">
                  <span className="font-bold">生成成功！代码: </span>
                  <span className="font-mono text-lg bg-white px-2 py-1 rounded border border-green-300 ml-2 select-all">{generatedCode}</span>
                </div>
              )}
            </div>

            {/* Codes List */}
            <div>
              <h3 className="text-lg font-bold text-slate-900 mb-4">兑换码列表</h3>
              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="min-w-full divide-y divide-slate-200">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">代码</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">面额</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">状态</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">创建时间</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-slate-200">
                    {redemptionCodes.length === 0 ? (
                       <tr><td colSpan={4} className="px-6 py-4 text-center text-slate-500">暂无兑换码</td></tr>
                    ) : (
                      [...redemptionCodes].reverse().map(code => (
                        <tr key={code.id}>
                          <td className="px-6 py-4 whitespace-nowrap font-mono text-sm text-slate-900">
                            {code.code}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {code.points} 积分
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {code.isUsed ? (
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">已使用</span>
                            ) : (
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">有效</span>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {format(new Date(code.createdAt), 'yyyy-MM-dd HH:mm')}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">用户</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">账号/昵称</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">状态</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">角色</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">注册时间</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">操作</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <img className="h-8 w-8 rounded-full bg-slate-100" src={u.avatar} alt="" />
                        <div className="ml-4">
                          <div className="text-sm font-medium text-slate-900">{u.nickname || u.username}</div>
                          <div className="text-xs text-slate-500">ID: {u.id.slice(0, 8)}...</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-slate-900">@{u.username}</div>
                        <div className="text-xs text-slate-500">{u.nickname}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                       {u.isBanned ? (
                         <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">已封禁</span>
                       ) : (
                         <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">正常</span>
                       )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${u.role === 'admin' ? 'bg-indigo-100 text-indigo-800' : 'bg-slate-100 text-slate-800'}`}>
                        {u.role === 'admin' ? '管理员' : '会员'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                      {format(new Date(u.createdAt), 'yyyy-MM-dd')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex gap-2">
                       <Link 
                          to={`/profile/${u.id}`}
                          className="text-indigo-600 hover:text-indigo-900"
                          title="查看资料"
                        >
                          <ExternalLink size={18} />
                        </Link>
                      {u.role !== 'admin' && (
                        <>
                          <button 
                            onClick={() => {
                              if(window.confirm(u.isBanned ? '确定解除封禁？' : '确定封禁该用户？')) {
                                updateUserStatus(u.id, !u.isBanned);
                                refreshUsers();
                              }
                            }}
                            className={`${u.isBanned ? 'text-green-600' : 'text-orange-600'} hover:underline`}
                            title={u.isBanned ? "解封" : "封禁"}
                          >
                            {u.isBanned ? <CheckCircle size={18} /> : <Ban size={18} />}
                          </button>
                          
                          <button 
                            onClick={() => {
                              if(window.confirm('确定重置该用户密码？')) {
                                resetUserPassword(u.id);
                              }
                            }}
                            className="text-blue-600 hover:text-blue-900"
                            title="重置密码"
                          >
                            <Lock size={18} />
                          </button>

                          <button 
                            onClick={() => {
                              if(window.confirm('确定彻底删除该用户？操作不可逆！')) {
                                deleteUser(u.id);
                                refreshUsers();
                              }
                            }}
                            className="text-red-600 hover:text-red-900"
                            title="删除用户"
                          >
                            <Trash2 size={18} />
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Threads Tab */}
        {activeTab === 'threads' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">帖子标题</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">作者</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">板块</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">状态</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">置顶/精华</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">发布时间</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">操作</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {threads.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center text-slate-500">
                      暂无帖子
                    </td>
                  </tr>
                ) : (
                  threads.map((thread) => {
                    const category = categories.find(c => c.id === thread.categoryId);
                    return (
                      <tr key={thread.id}>
                        <td className="px-6 py-4">
                          <Link to={`/thread/${thread.id}`} className="text-sm font-medium text-indigo-600 hover:text-indigo-900 truncate block max-w-xs" title={thread.title}>
                            {thread.title}
                          </Link>
                          <div className="text-xs text-slate-500 mt-1">
                            浏览: {thread.views || 0}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          {thread.authorName}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          {category?.name || '未知板块'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {thread.deletedAt ? (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">已删除</span>
                          ) : (
                            <>
                              {thread.status === 'approved' && (
                                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">已发布</span>
                              )}
                              {thread.status === 'pending' && (
                                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">待审核</span>
                              )}
                              {thread.status === 'rejected' && (
                                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">已拒绝</span>
                              )}
                              {thread.isHidden && (
                                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800 ml-1">已隐藏</span>
                              )}
                            </>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            {thread.isPinned && (
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-orange-100 text-orange-800">📌 置顶</span>
                            )}
                            {thread.isFeatured && (
                              <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">💎 精华</span>
                            )}
                            {!thread.isPinned && !thread.isFeatured && (
                              <span className="text-slate-400 text-xs">普通</span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          {format(new Date(thread.createdAt), 'yyyy-MM-dd HH:mm')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => togglePinThread(thread.id)}
                              className={`px-2 py-1 rounded text-xs font-medium ${thread.isPinned ? 'bg-orange-100 text-orange-700 hover:bg-orange-200' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                              title={thread.isPinned ? "取消置顶" : "设为置顶"}
                            >
                              📌 {thread.isPinned ? '取消置顶' : '置顶'}
                            </button>
                            <button 
                              onClick={() => toggleFeatureThread(thread.id)}
                              className={`px-2 py-1 rounded text-xs font-medium ${thread.isFeatured ? 'bg-purple-100 text-purple-700 hover:bg-purple-200' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                              title={thread.isFeatured ? "取消精华" : "设为精华"}
                            >
                              💎 {thread.isFeatured ? '取消精华' : '加精'}
                            </button>
                            <button 
                              onClick={() => toggleThreadVisibility(thread.id)}
                              className={`px-2 py-1 rounded text-xs font-medium ${thread.isHidden ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'}`}
                              title={thread.isHidden ? "显示帖子" : "隐藏帖子"}
                            >
                              {thread.isHidden ? '显示' : '隐藏'}
                            </button>
                            {thread.deletedAt ? (
                              <>
                                <button 
                                  onClick={() => restoreThread(thread.id)}
                                  className="px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-700 hover:bg-green-200"
                                  title="恢复帖子"
                                >
                                  恢复
                                </button>
                                <button 
                                  onClick={() => {
                                    if(window.confirm('确定永久删除此帖子？操作不可逆！')) {
                                      permanentlyDeleteThread(thread.id);
                                    }
                                  }}
                                  className="text-red-600 hover:text-red-900"
                                  title="永久删除"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </>
                            ) : (
                              <button 
                                onClick={() => deleteThread(thread.id)}
                                className="px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-700 hover:bg-red-200"
                                title="软删除 (7天后永久删除)"
                              >
                                删除
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Categories Tab */}
        {activeTab === 'categories' && (
          <div className="overflow-x-auto">
             <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">名称</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">描述</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">操作</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {categories.map((c) => (
                  <tr key={c.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">
                      {c.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                      {c.description}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                       <button 
                         onClick={() => {
                           if(window.confirm('确定删除此板块？此操作不可逆！')) deleteCategory(c.id);
                         }}
                         className="text-red-600 hover:text-red-900"
                       >
                         <Trash2 size={18} />
                       </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
