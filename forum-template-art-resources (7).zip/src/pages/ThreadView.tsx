import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useForum } from '../context/ForumContext';
import { useAuth } from '../context/AuthContext';
import BlockEditor from '../components/BlockEditor';
import BlockRenderer from '../components/BlockRenderer';
import { ContentBlock, Post } from '../types';
import { format } from 'date-fns';
import { MessageSquare, Lock, Trash2, Eye, EyeOff, ShieldCheck, Edit, UserPlus, UserCheck, Heart, Share2, Bookmark, BookmarkCheck } from 'lucide-react';

export const ThreadView: React.FC = () => {
  const { threadId } = useParams<{ threadId: string }>();
  const { getThread, getPostsByThread, createPost, deleteThread, toggleThreadVisibility, likeThread, shareThread } = useForum();
  const { user, followUser, unfollowUser, purchaseThread, isFollowing, isMutualFollow, addFavorite, removeFavorite, isFavorite } = useAuth();
  const navigate = useNavigate();
  
  const [replyBlocks, setReplyBlocks] = useState<ContentBlock[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [replyingTo, setReplyingTo] = useState<{ id: string; author: string } | null>(null);
  const [showShareToast, setShowShareToast] = useState(false);

  const thread = threadId ? getThread(threadId) : undefined;
  const posts = threadId ? getPostsByThread(threadId) : [];

  if (!thread) return <div className="text-center py-12">找不到帖子</div>;
  
  const userFollowsAuthor = isFollowing(thread.authorId);
  const isMutual = isMutualFollow(thread.authorId);
  const isAuthor = user?.id === thread.authorId;
  const isAdmin = user?.role === 'admin';
  const hasReplied = user && posts.some(p => p.authorId === user.id);
  const hasPurchased = user?.purchasedThreads?.includes(thread.id);
  const isLiked = user && (thread.likes || []).includes(user.id);
  const isFav = isFavorite(thread.id);

  let canViewHidden = isAuthor || isAdmin;
  if (thread.hideType === 'reply' && hasReplied) canViewHidden = true;
  if (thread.hideType === 'pay' && hasPurchased) canViewHidden = true;
  if (thread.hideType === 'none') canViewHidden = true;

  const handleReply = async () => {
    if (replyBlocks.length === 0 || !user) return;
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 300));
    createPost(thread.id, JSON.stringify(replyBlocks), user, replyingTo?.id);
    setReplyBlocks([]);
    setReplyingTo(null);
    setIsSubmitting(false);
  };

  const handleDelete = () => {
    if (window.confirm('确定要删除这个帖子吗？此操作无法撤销。')) {
      deleteThread(thread.id);
      navigate(`/category/${thread.categoryId}`);
    }
  };

  const handleToggleHide = () => {
    toggleThreadVisibility(thread.id);
  };
  
  const handleEdit = () => {
    navigate(`/edit/${thread.id}`);
  };

  const handlePurchase = () => {
    if (!user) return;
    if (user.points < (thread.price || 0)) {
      alert(`积分不足！您当前拥有 ${user.points} 积分，需要 ${thread.price} 积分。`);
      return;
    }
    if (window.confirm(`确定花费 ${thread.price} 积分购买此内容吗？`)) {
      const success = purchaseThread(thread.id, thread.price || 0, thread.authorId);
      if (success) {
        alert('购买成功！');
      } else {
        alert('购买失败，请重试');
      }
    }
  };

  const handleLike = () => {
    if (!user) {
      alert('请先登录');
      return;
    }
    likeThread(thread.id, user.id);
  };

  const handleShare = () => {
    shareThread(thread.id);
    setShowShareToast(true);
    setTimeout(() => setShowShareToast(false), 2000);
  };

  const handleFavorite = () => {
    if (!user) {
      alert('请先登录');
      return;
    }
    if (isFav) {
      removeFavorite(thread.id);
    } else {
      addFavorite(thread.id);
    }
  };

  const handleFollow = () => {
    if (userFollowsAuthor) {
      unfollowUser(thread.authorId);
    } else {
      followUser(thread.authorId);
    }
  };

  // Helper to render post and its children
  const renderPost = (post: Post, index: number, isChild = false) => {
    const children = posts.filter(p => p.parentId === post.id);

    return (
      <div key={post.id} className={`${isChild ? 'ml-12 mt-2' : 'mt-4'} bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden`}>
         <div className="flex flex-col md:flex-row min-h-[100px]">
           <div className="md:w-32 bg-slate-50 p-4 flex flex-col items-center text-center border-b md:border-b-0 md:border-r border-slate-200">
             <Link to={`/profile/${post.authorId}`}>
               <img 
                 src={post.authorAvatar} 
                 alt={post.authorName} 
                 className="w-12 h-12 rounded-full bg-slate-200 mb-2 object-cover"
               />
               <div className="font-bold text-slate-900 text-sm truncate w-full">{post.authorName}</div>
             </Link>
           </div>
           <div className="flex-1 p-4">
             <div className="flex justify-between items-center mb-2 pb-2 border-b border-slate-100">
               <span className="text-xs text-slate-400">
                 {format(new Date(post.createdAt), 'yyyy年MM月dd日 HH:mm')}
               </span>
               <div className="flex items-center gap-2">
                 <span className="text-xs text-slate-400">#{index}</span>
                 {user && (
                   <button 
                     onClick={() => {
                        setReplyingTo({ id: post.id, author: post.authorName });
                        document.getElementById('reply-editor')?.scrollIntoView({ behavior: 'smooth' });
                     }}
                     className="text-xs text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                   >
                     <MessageSquare size={12} /> 回复
                   </button>
                 )}
               </div>
             </div>
             
             <BlockRenderer content={post.content} />
           </div>
         </div>
         {children.length > 0 && (
           <div className="p-2 bg-slate-50 border-t border-slate-200">
              {children.map((child, cIdx) => renderPost(child, cIdx + 1, true))}
           </div>
         )}
      </div>
    );
  };

  const topLevelPosts = posts.filter(p => !p.parentId);

  return (
    <div className="space-y-6">
      {/* Share Toast */}
      {showShareToast && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-pulse">
          链接已复制到剪贴板！
        </div>
      )}

      {/* Cover Image Banner - Rectangular 16:9 */}
      {thread.coverImage && (
        <div className="w-full aspect-[21/9] max-h-80 rounded-xl overflow-hidden shadow-lg">
          <img 
            src={thread.coverImage} 
            alt={thread.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      
      {/* Reward Banner */}
      {thread.rewardConfig && thread.rewardConfig.enabled && (
        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-4 rounded-lg shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🎁</span>
              <div>
                <div className="font-bold text-lg">回帖抽奖</div>
                <div className="text-orange-100 text-sm">
                  每次中奖 {thread.rewardConfig.amountPerReward} 积分，中奖概率 {thread.rewardConfig.probability}%
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">
                {thread.rewardConfig.remainingBudget > 0 
                  ? `${thread.rewardConfig.remainingBudget} 积分` 
                  : '奖励已发完'}
              </div>
              <div className="text-orange-100 text-sm">剩余奖池</div>
            </div>
          </div>
        </div>
      )}

      {/* Thread Header & Admin Controls */}
      <div className="border-b border-slate-200 pb-4">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
              {thread.isHidden && <span className="text-red-500 text-sm border border-red-500 px-2 rounded">[已隐藏]</span>}
              {thread.status === 'pending' && <span className="text-yellow-600 text-sm bg-yellow-100 px-2 py-0.5 rounded border border-yellow-200">[待审核]</span>}
              {thread.status === 'rejected' && <span className="text-red-600 text-sm bg-red-100 px-2 py-0.5 rounded border border-red-200">[已拒绝]</span>}
              {thread.title}
            </h1>
            <div className="mt-2 flex items-center gap-4 text-sm text-slate-500">
               <Link to={`/category/${thread.categoryId}`} className="text-indigo-600 hover:underline">
                 返回板块
               </Link>
               <span>•</span>
               <span>{format(new Date(thread.createdAt), 'yyyy年MM月dd日 HH:mm')}</span>
               {thread.price && thread.price > 0 && (
                 <span className="text-orange-500 font-bold">• 售价: {thread.price} 积分</span>
               )}
            </div>
          </div>
          
          <div className="flex gap-2">
            {(isAuthor || isAdmin) && (
              <button 
                onClick={handleEdit}
                className="p-2 text-slate-500 hover:text-indigo-500 bg-slate-100 rounded"
                title="编辑帖子"
              >
                <Edit className="h-5 w-5" />
              </button>
            )}
            
            {isAdmin && (
              <>
                <button 
                  onClick={handleToggleHide}
                  className="p-2 text-slate-500 hover:text-orange-500 bg-slate-100 rounded"
                  title={thread.isHidden ? "恢复帖子" : "隐藏帖子"}
                >
                  {thread.isHidden ? <Eye className="h-5 w-5" /> : <EyeOff className="h-5 w-5" />}
                </button>
                <button 
                  onClick={handleDelete}
                  className="p-2 text-slate-500 hover:text-red-500 bg-slate-100 rounded"
                  title="删除帖子"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Social Buttons: Like, Share, Favorite */}
      <div className="flex items-center gap-4 bg-white p-4 rounded-lg border border-slate-200">
        <button 
          onClick={handleLike}
          className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all ${
            isLiked 
              ? 'bg-red-50 border-red-200 text-red-500' 
              : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-red-200 hover:text-red-500'
          }`}
        >
          <Heart className={`h-5 w-5 ${isLiked ? 'fill-current' : ''}`} />
          <span className="font-medium">{(thread.likes || []).length}</span>
          <span className="text-sm">点赞</span>
        </button>

        <button 
          onClick={handleShare}
          className="flex items-center gap-2 px-4 py-2 rounded-full border bg-slate-50 border-slate-200 text-slate-600 hover:border-blue-200 hover:text-blue-500 transition-all"
        >
          <Share2 className="h-5 w-5" />
          <span className="font-medium">{thread.shares || 0}</span>
          <span className="text-sm">分享</span>
        </button>

        <button 
          onClick={handleFavorite}
          className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all ${
            isFav 
              ? 'bg-yellow-50 border-yellow-200 text-yellow-600' 
              : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-yellow-200 hover:text-yellow-600'
          }`}
        >
          {isFav ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
          <span className="text-sm">{isFav ? '已收藏' : '收藏'}</span>
        </button>

        <div className="flex-1"></div>

        <div className="flex items-center gap-2 text-sm text-slate-500">
          <Eye className="h-4 w-4" />
          <span>{thread.views || 0} 浏览</span>
          <span>•</span>
          <MessageSquare className="h-4 w-4" />
          <span>{thread.replies} 回复</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Main Thread Post (Floor 1) */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden ring-2 ring-indigo-50">
           <div className="flex flex-col md:flex-row min-h-[200px]">
             {/* Author Sidebar */}
             <div className="md:w-48 bg-slate-50 p-6 flex flex-col items-center text-center border-b md:border-b-0 md:border-r border-slate-200">
               <div className="relative">
                 <Link to={`/profile/${thread.authorId}`}>
                    <img 
                      src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${thread.authorName}`} 
                      alt={thread.authorName} 
                      className="w-20 h-20 rounded-full bg-slate-200 mb-3 object-cover border-4 border-white shadow-sm"
                    />
                 </Link>
                 <span className="absolute -bottom-1 -right-1 bg-indigo-500 text-white text-xs px-2 py-0.5 rounded-full">楼主</span>
               </div>
               <div className="font-bold text-slate-900">
                 <Link to={`/profile/${thread.authorId}`}>{thread.authorName}</Link>
               </div>
               <div className="text-xs text-slate-500 mt-1">
                  {thread.authorName === 'admin' ? '管理员' : '会员'}
               </div>
               
               {/* Follow Button with Mutual Indicator */}
               {user && !isAuthor && (
                 <div className="mt-3 flex flex-col items-center gap-1">
                   <button 
                     onClick={handleFollow}
                     className={`flex items-center gap-1 text-xs px-3 py-1 rounded-full border transition-colors ${
                       userFollowsAuthor 
                         ? 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200' 
                         : 'bg-indigo-50 text-indigo-600 border-indigo-200 hover:bg-indigo-100'
                     }`}
                   >
                     {userFollowsAuthor ? (
                       <>
                         <UserCheck className="h-3 w-3" />
                         {isMutual ? '互相关注' : '已关注'}
                       </>
                     ) : (
                       <>
                         <UserPlus className="h-3 w-3" />
                         关注
                       </>
                     )}
                   </button>
                   {isMutual && (
                     <Link 
                       to="/messages" 
                       className="text-xs text-indigo-500 hover:underline"
                     >
                       发私信
                     </Link>
                   )}
                 </div>
               )}
             </div>
             
             {/* Content Area */}
             <div className="flex-1 p-6 relative">
               <div className="flex justify-between items-center mb-4 pb-2 border-b border-slate-100">
                 <span className="text-xs text-slate-400">
                   发布于 {format(new Date(thread.createdAt), 'yyyy年MM月dd日 HH:mm')}
                 </span>
                 <span className="text-xs font-bold text-indigo-100 bg-indigo-500 px-2 py-1 rounded">1楼</span>
               </div>
               
               <BlockRenderer blocks={thread.blocks} />

               {/* Hidden Content Section */}
               {thread.hideType !== 'none' && thread.hiddenContent && (
                 <div className="mt-8 p-6 bg-slate-50 border border-slate-200 rounded-lg">
                   <div className="flex items-center gap-2 mb-4 font-bold text-slate-800">
                     <Lock className="h-5 w-5 text-indigo-600" />
                     <span>隐藏内容</span>
                     <span className="text-xs font-normal text-slate-500 bg-white px-2 py-1 rounded border">
                       {thread.hideType === 'reply' ? '回复可见' : `付费可见 (${thread.price} 积分)`}
                     </span>
                   </div>
                   
                   {canViewHidden ? (
                     <div className="bg-green-50 p-4 rounded border border-green-200 text-green-900">
                       <div className="font-semibold mb-2 flex items-center gap-2">
                         <ShieldCheck className="h-5 w-5" />
                         您已获得查看权限：
                       </div>
                       <div className="whitespace-pre-wrap">{thread.hiddenContent}</div>
                     </div>
                   ) : (
                     <div className="text-center py-6 bg-white rounded border border-slate-200 border-dashed">
                       <p className="text-slate-600 mb-4">
                         {thread.hideType === 'reply' 
                           ? '此处包含隐藏内容，请回复后查看。' 
                           : `此处包含付费内容，需要支付 ${thread.price} 积分。`}
                       </p>
                       
                       {thread.hideType === 'pay' && user && (
                         <button 
                           onClick={handlePurchase}
                           className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded-md font-bold shadow-sm transition-colors"
                         >
                           立即购买 ({thread.price} 积分)
                         </button>
                       )}
                       
                       {!user && (
                         <Link to="/login" className="text-indigo-600 hover:underline font-medium">
                           请先登录
                         </Link>
                       )}
                     </div>
                   )}
                 </div>
               )}
             </div>
           </div>
        </div>

        {/* Replies List (Recursive) */}
        {topLevelPosts.map((post, index) => renderPost(post, index + 2))}
      </div>

      <div className="mt-8 bg-white rounded-lg shadow-sm border border-slate-200 p-6" id="reply-editor">
        {user ? (
          <div>
            <h3 className="text-lg font-medium text-slate-900 mb-4 flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              {replyingTo ? (
                <span>
                   回复 <span className="text-indigo-600">@{replyingTo.author}</span>
                   <button onClick={() => setReplyingTo(null)} className="ml-2 text-xs text-slate-400 hover:text-slate-600">(取消)</button>
                </span>
              ) : '回复帖子'}
            </h3>
            <BlockEditor 
              blocks={replyBlocks} 
              onChange={setReplyBlocks} 
            />
            <div className="flex justify-end mt-4">
              <button
                onClick={handleReply}
                disabled={isSubmitting || replyBlocks.length === 0}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-md font-medium disabled:opacity-50"
              >
                {isSubmitting ? '回复中...' : '发表回复'}
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-slate-600 mb-4">您必须登录后才能回复。</p>
            <Link 
              to="/login" 
              className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-md font-medium"
            >
              登录
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};
