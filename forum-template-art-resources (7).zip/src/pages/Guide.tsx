import React from 'react';

export const Guide: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-200">
        <h1 className="text-3xl font-bold text-slate-900 mb-8 text-center">社区玩法说明</h1>
        
        <section className="mb-12">
          <h2 className="text-xl font-bold text-indigo-600 mb-4 flex items-center gap-2">
            <span>💎</span> 积分体系
          </h2>
          <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 rounded-lg">
            <table className="min-w-full divide-y divide-slate-300">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-slate-900 sm:pl-6">行为</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-900">积分变动</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-900">说明</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">每日登录</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-green-600 font-bold">+10</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">每天首次访问社区自动发放</td>
                </tr>
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">发布新帖</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-green-600 font-bold">+10</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">鼓励分享优质资源</td>
                </tr>
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">回复帖子</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-green-600 font-bold">+2</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">参与讨论，禁止灌水</td>
                </tr>
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">邀请新用户 (邀请人)</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-green-600 font-bold">+50</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">被邀请人注册成功后自动发放</td>
                </tr>
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">使用邀请码注册 (新用户)</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-green-600 font-bold">+30</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">额外奖励（初始100+30=130积分）</td>
                </tr>
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">回帖抽奖中奖</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-green-600 font-bold">+N</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">部分帖子有回帖奖励，按概率中奖</td>
                </tr>
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">获得打赏</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-green-600 font-bold">+N</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">其他用户对您的内容进行打赏</td>
                </tr>
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">查看隐藏内容</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-red-600 font-bold">-N</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">支付积分给作者以解锁内容</td>
                </tr>
                <tr>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-900 sm:pl-6">打赏他人</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-red-600 font-bold">-N</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-500">支持您喜爱的创作者</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-indigo-600 mb-6 flex items-center gap-2">
            <span>❓</span> 常见问题 (FAQ)
          </h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-slate-900">Q: 如何获取更多积分？</h3>
              <p className="mt-2 text-slate-600">
                A: 除了日常活跃外，您可以通过"赞助我们"来支持服务器运行，管理员会为您发放积分兑换码。
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-slate-900">Q: 什么是"隐藏内容"？</h3>
              <p className="mt-2 text-slate-600">
                A: 作者可以设置部分内容（如下载链接、关键素材）为"回复可见"或"付费可见"。付费可见的内容需要您支付相应的积分，这些积分会直接转给作者。
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-slate-900">Q: 兑换码在哪里使用？</h3>
              <p className="mt-2 text-slate-600">
                A: 进入个人中心（点击右上角头像），在"积分"栏目旁找到兑换入口，输入兑换码即可立即到账。
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium text-slate-900">Q: 如何获取邀请码？</h3>
              <p className="mt-2 text-slate-600">
                A: 登录后进入"个人中心"，在个人信息卡片中可以看到您的专属邀请码。复制后分享给朋友即可。
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium text-slate-900">Q: 邀请奖励如何发放？</h3>
              <p className="mt-2 text-slate-600">
                A: 当朋友使用您的邀请码成功注册后，系统会自动发放奖励：<strong>您获得 50 积分</strong>，<strong>您的朋友获得 30 额外积分</strong>（初始积分变为 130）。双方都有奖励！
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium text-slate-900">Q: 什么是回帖抽奖？</h3>
              <p className="mt-2 text-slate-600">
                A: 发帖人可以设置回帖奖励，从自己的积分中拿出一部分作为奖励池。您在这类帖子回复时，有一定概率中奖获得积分。概率和金额由发帖人设定。带有🎁标签的帖子即有回帖奖励。
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium text-slate-900">Q: 社区有哪些禁止行为？</h3>
              <p className="mt-2 text-slate-600">
                A: 禁止发布违法违规内容、恶意广告、无意义灌水（如"666"、"顶"）。发布外链会自动进入审核队列，请耐心等待管理员通过。
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
