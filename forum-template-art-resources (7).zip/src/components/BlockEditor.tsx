import React, { useState } from 'react';
import { ContentBlock, BlockType } from '../types';
import { Trash2, Image as ImageIcon, Type, Video, Heading, ArrowUp, ArrowDown, Smile } from 'lucide-react';

interface BlockEditorProps {
  blocks: ContentBlock[];
  onChange: (blocks: ContentBlock[]) => void;
}

const COMMON_EMOJIS = [
  '😀', '😂', '🤣', '😊', '😍', '🤔', '😎', '😭', '😡', '👍', '👎', '🙏', '🎉', '🔥', '❤️', '💔', '💩', '👻', '💀', '👽',
  '👀', '🧠', '💪', '🤝', '🙌', '👏', '👋', '🤷', '🤦', '🤖', '👾', '🎮', '🎨', '🖌️', '✨', '🌟', '💫', '💥', '💢', '💤'
];

const BlockEditor: React.FC<BlockEditorProps> = ({ blocks, onChange }) => {
  const [activeEmojiBlockId, setActiveEmojiBlockId] = useState<string | null>(null);

  const addBlock = (type: BlockType) => {
    const newBlock: ContentBlock = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      type,
      value: ''
    };
    onChange([...blocks, newBlock]);
  };

  const updateBlock = (id: string, value: string) => {
    onChange(blocks.map(b => b.id === id ? { ...b, value } : b));
  };

  const removeBlock = (id: string) => {
    onChange(blocks.filter(b => b.id !== id));
  };

  const moveBlock = (index: number, direction: 'up' | 'down') => {
    if (
      (direction === 'up' && index === 0) || 
      (direction === 'down' && index === blocks.length - 1)
    ) return;

    const newBlocks = [...blocks];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    const [movedBlock] = newBlocks.splice(index, 1);
    newBlocks.splice(targetIndex, 0, movedBlock);
    onChange(newBlocks);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, blockId: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 512 * 1024) {
      alert('图片大小不能超过 512KB');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      updateBlock(blockId, base64);
    };
    reader.readAsDataURL(file);
  };

  const insertEmoji = (blockId: string, currentValue: string, emoji: string) => {
    updateBlock(blockId, currentValue + emoji);
    setActiveEmojiBlockId(null);
  };

  const renderVideoPreview = (value: string) => {
    if (!value) return null;
    let src = '';
    
    // Check for iframe code
    if (value.includes('<iframe')) {
      const match = value.match(/src="([^"]+)"/);
      if (match) src = match[1];
    } 
    // Check for full URL
    else if (value.includes('bilibili.com')) {
       // Try to extract BV
       const bvMatch = value.match(/(BV\w+)/);
       if (bvMatch) {
         src = `//player.bilibili.com/player.html?bvid=${bvMatch[1]}&page=1&high_quality=1&danmaku=0`;
       }
    }
    // Check for just BV code
    else if (value.startsWith('BV')) {
      src = `//player.bilibili.com/player.html?bvid=${value}&page=1&high_quality=1&danmaku=0`;
    }

    if (!src) return <div className="text-red-500 text-sm mt-2">无法识别的视频代码</div>;

    return (
      <div className="mt-2 w-full aspect-video bg-black rounded-lg overflow-hidden shadow-md">
        <iframe
          src={src}
          className="w-full h-full"
          scrolling="no"
          frameBorder="0"
          allowFullScreen
        />
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex gap-2 p-2 bg-gray-50 border rounded-lg flex-wrap sticky top-0 z-10 shadow-sm">
        <button
          type="button"
          onClick={() => addBlock('header')}
          className="flex items-center gap-2 px-3 py-2 bg-white border rounded hover:bg-gray-100 transition-colors text-sm font-medium text-slate-700"
        >
          <Heading size={16} />
          <span>标题</span>
        </button>
        <button
          type="button"
          onClick={() => addBlock('text')}
          className="flex items-center gap-2 px-3 py-2 bg-white border rounded hover:bg-gray-100 transition-colors text-sm font-medium text-slate-700"
        >
          <Type size={16} />
          <span>文本</span>
        </button>
        <button
          type="button"
          onClick={() => addBlock('image')}
          className="flex items-center gap-2 px-3 py-2 bg-white border rounded hover:bg-gray-100 transition-colors text-sm font-medium text-slate-700"
        >
          <ImageIcon size={16} />
          <span>图片</span>
        </button>
        <button
          type="button"
          onClick={() => addBlock('video')}
          className="flex items-center gap-2 px-3 py-2 bg-white border rounded hover:bg-gray-100 transition-colors text-sm font-medium text-slate-700"
        >
          <Video size={16} />
          <span>视频</span>
        </button>
      </div>

      {/* Blocks List */}
      <div className="space-y-4 min-h-[200px] border-2 border-dashed border-gray-200 rounded-lg p-4 bg-gray-50/30">
        {blocks.length === 0 && (
          <div className="text-center text-gray-400 py-10 flex flex-col items-center">
            <div className="bg-gray-100 p-4 rounded-full mb-3">
              <Type size={32} className="text-gray-300" />
            </div>
            点击上方按钮添加内容模块
          </div>
        )}
        
        {blocks.map((block, index) => (
          <div key={block.id} className="relative group bg-white border rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
            {/* Control Buttons */}
            <div className="absolute right-2 top-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 p-1 rounded z-10 border shadow-sm">
              <button
                type="button"
                onClick={() => moveBlock(index, 'up')}
                disabled={index === 0}
                className="p-1 hover:bg-gray-100 rounded disabled:opacity-30"
                title="上移"
              >
                <ArrowUp size={16} />
              </button>
              <button
                type="button"
                onClick={() => moveBlock(index, 'down')}
                disabled={index === blocks.length - 1}
                className="p-1 hover:bg-gray-100 rounded disabled:opacity-30"
                title="下移"
              >
                <ArrowDown size={16} />
              </button>
              <button
                type="button"
                onClick={() => removeBlock(block.id)}
                className="p-1 hover:bg-red-50 text-red-500 rounded"
                title="删除"
              >
                <Trash2 size={16} />
              </button>
            </div>

            <div className="pr-12">
              <label className="block text-xs font-bold text-gray-400 mb-2 uppercase tracking-wide">
                {block.type === 'header' && '标题模块'}
                {block.type === 'text' && '文本模块'}
                {block.type === 'image' && '图片模块'}
                {block.type === 'video' && '视频模块'}
              </label>

              {block.type === 'header' && (
                <input
                  type="text"
                  value={block.value}
                  onChange={(e) => updateBlock(block.id, e.target.value)}
                  placeholder="请输入大标题..."
                  className="w-full text-2xl font-bold border-b border-gray-200 focus:border-indigo-500 outline-none py-2 bg-transparent"
                />
              )}

              {block.type === 'text' && (
                <div className="relative">
                  <textarea
                    value={block.value}
                    onChange={(e) => updateBlock(block.id, e.target.value)}
                    placeholder="请输入正文内容..."
                    rows={4}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500 outline-none resize-y text-gray-700 leading-relaxed"
                  />
                  <div className="absolute bottom-2 right-2">
                    <button
                      type="button"
                      onClick={() => setActiveEmojiBlockId(activeEmojiBlockId === block.id ? null : block.id)}
                      className="p-1.5 text-gray-400 hover:text-yellow-500 hover:bg-yellow-50 rounded-full transition-colors"
                      title="插入表情"
                    >
                      <Smile size={20} />
                    </button>
                  </div>
                  
                  {activeEmojiBlockId === block.id && (
                    <div className="absolute bottom-10 right-0 z-20 bg-white border shadow-lg rounded-lg p-2 w-64">
                      <div className="grid grid-cols-6 gap-1 max-h-40 overflow-y-auto">
                        {COMMON_EMOJIS.map(emoji => (
                          <button
                            key={emoji}
                            type="button"
                            onClick={() => insertEmoji(block.id, block.value, emoji)}
                            className="p-1 hover:bg-gray-100 rounded text-lg"
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {block.type === 'image' && (
                <div className="space-y-3">
                   <div className="flex items-center gap-4">
                      <label className="cursor-pointer flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors">
                        <ImageIcon size={18} />
                        <span>选择图片 (Max 512KB)</span>
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, block.id)}
                        />
                      </label>
                      <span className="text-xs text-gray-400">支持 jpg, png, gif</span>
                   </div>
                  
                  {block.value ? (
                    <div className="relative mt-2 rounded-lg overflow-hidden bg-gray-100 border max-w-md">
                       <img src={block.value} alt="Preview" className="w-full h-auto object-contain" />
                       <button 
                         onClick={() => updateBlock(block.id, '')}
                         className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                         title="移除图片"
                       >
                         <Trash2 size={12} />
                       </button>
                    </div>
                  ) : (
                    <div className="h-32 bg-gray-50 rounded-lg border-2 border-dashed flex items-center justify-center text-gray-300">
                      暂无图片
                    </div>
                  )}
                </div>
              )}

              {block.type === 'video' && (
                <div className="space-y-3">
                  <input
                    type="text"
                    value={block.value}
                    onChange={(e) => updateBlock(block.id, e.target.value)}
                    placeholder="输入 B站 BV号 (如 BV1zE...) 或 嵌入代码"
                    className="w-full p-2 border rounded focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none font-mono text-sm"
                  />
                  {renderVideoPreview(block.value)}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BlockEditor;
